#!/usr/bin/env node
/**
 * Computes the x-fenx-signature header value for a webhook request body.
 *
 * Usage:
 *   node scripts/generate-signature.js <body-file> <secret>
 *
 * Example:
 *   node scripts/generate-signature.js postman/sample-single-completed.json "<WEBHOOK_SECRET>"
 *
 * IMPORTANT: sign the EXACT bytes you will send. Send the same file with
 * curl --data-binary so no whitespace or line-ending changes occur:
 *
 *   SIGNATURE=$(node scripts/generate-signature.js body.json "<WEBHOOK_SECRET>")
 *   curl -i -X POST http://localhost:3000/api/webhooks/fenergo/journey-status \
 *     -H "content-type: application/json" \
 *     -H "x-fenx-signature: $SIGNATURE" \
 *     --data-binary @body.json
 */
const crypto = require('node:crypto');
const fs = require('node:fs');

const [, , bodyFilePath, webhookSecret] = process.argv;
if (!bodyFilePath || !webhookSecret) {
  console.error('Usage: node scripts/generate-signature.js <body-file> <secret>');
  process.exit(1);
}

const rawBodyBytes = fs.readFileSync(bodyFilePath);
const digestHex = crypto
  .createHmac('sha256', Buffer.from(webhookSecret, 'utf8'))
  .update(rawBodyBytes)
  .digest('hex')
  .toUpperCase();

console.log(`sha256=${digestHex}`);
