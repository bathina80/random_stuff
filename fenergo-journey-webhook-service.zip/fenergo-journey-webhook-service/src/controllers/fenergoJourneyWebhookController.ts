import type { FastifyReply, FastifyRequest } from 'fastify';
import type { AppConfig } from '../config/config';
import type { FenergoJourneyWebhookService } from '../services/fenergoJourneyWebhookService';
import type { FenergoSignatureService } from '../services/fenergoSignatureService';
import { InvalidWebhookPayloadError } from '../types/errors';

/**
 * Thin HTTP controller for POST /api/webhooks/fenergo/journey-status.
 *
 * Status codes:
 *   202 — processed, duplicate, or unsupported-and-ignored (also: feature flag off)
 *   401 — missing or invalid HMAC signature
 *   400 — malformed payload
 *   500 — unexpected processing / downstream failure (Fenergo retry desirable)
 *
 * No stack traces are ever exposed to the caller, and neither the webhook
 * secret nor any Authorization header is ever logged.
 */
export class FenergoJourneyWebhookController {
  constructor(
    private readonly appConfig: AppConfig,
    private readonly webhookService: FenergoJourneyWebhookService,
    private readonly signatureService?: FenergoSignatureService,
  ) {}

  async handleJourneyStatusWebhook(request: FastifyRequest, reply: FastifyReply): Promise<void> {
    request.log.info({ rawBodyLength: request.rawBody?.length ?? 0 }, 'Fenergo journey webhook received');

    if (this.appConfig.signatureValidationEnabled) {
      const signatureHeader = request.headers['x-fenx-signature'];
      const signatureIsValid =
        this.signatureService !== undefined &&
        this.signatureService.isValidSignature(request.rawBody, signatureHeader);
      if (!signatureIsValid) {
        request.log.warn(
          {
            rawBodyLength: request.rawBody?.length ?? 0,
            signatureHeaderPresent: signatureHeader !== undefined,
          },
          'Fenergo signature validation failed',
        );
        await reply.status(401).send({ error: 'Invalid or missing webhook signature' });
        return;
      }
      request.log.debug({}, 'Fenergo signature validation succeeded');
    }

    if (!this.appConfig.journeyWebhookEnabled) {
      request.log.info({}, 'Fenergo journey webhook is disabled; notification acknowledged without processing');
      await reply.status(202).send({ status: 'accepted', disabled: true });
      return;
    }

    try {
      const processingSummary = await this.webhookService.handleWebhookPayload(request.body);
      await reply.status(202).send({
        status: 'accepted',
        received: processingSummary.received,
        processed: processingSummary.processed,
        duplicates: processingSummary.duplicates,
        ignored: processingSummary.ignored,
        ...(processingSummary.batchId !== undefined ? { batchId: processingSummary.batchId } : {}),
        ...(processingSummary.moreAvailable !== undefined
          ? { moreAvailable: processingSummary.moreAvailable }
          : {}),
      });
    } catch (webhookFailure) {
      if (webhookFailure instanceof InvalidWebhookPayloadError) {
        request.log.warn({ reason: webhookFailure.message }, 'Fenergo webhook processing failed');
        await reply.status(400).send({ error: webhookFailure.message });
        return;
      }
      const failureError = webhookFailure as Error;
      request.log.error(
        { errorName: failureError.name, errorMessage: failureError.message },
        'Fenergo webhook processing failed',
      );
      await reply.status(500).send({ error: 'Webhook processing failed' });
    }
  }
}
