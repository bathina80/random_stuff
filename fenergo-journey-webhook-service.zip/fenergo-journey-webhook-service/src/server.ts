import 'dotenv/config';
import { buildApp } from './app';
import { loadConfig } from './config/config';

async function startServer(): Promise<void> {
  const appConfig = loadConfig();
  const app = buildApp(appConfig);

  try {
    await app.listen({ port: appConfig.port, host: appConfig.host });
  } catch (startupError) {
    app.log.error({ errorMessage: (startupError as Error).message }, 'Failed to start server');
    process.exit(1);
  }

  for (const shutdownSignal of ['SIGINT', 'SIGTERM'] as const) {
    process.on(shutdownSignal, () => {
      app.log.info({ shutdownSignal }, 'Shutting down');
      void app.close().then(() => process.exit(0));
    });
  }
}

void startServer().catch((fatalError: unknown) => {
  // Configuration errors are thrown before the logger exists; the message
  // names the missing variable but never contains a secret value.
  console.error(`Fatal startup error: ${(fatalError as Error).message}`);
  process.exit(1);
});
