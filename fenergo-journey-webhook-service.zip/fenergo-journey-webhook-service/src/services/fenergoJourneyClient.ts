import { JourneyQueryError } from '../types/errors';
import type { StructuredLogger } from '../types/loggerTypes';

/**
 * Minimal, defensive view of a Fenergo Journey Query response.
 *
 * IMPORTANT: the exact response schema MUST be confirmed against a real
 * Fenergo lower environment. Only commonly seen field names are probed here
 * (best-effort, several casings); nothing proprietary is assumed. The full
 * response body is retained in `raw` so downstream processors can extract
 * confirmed fields without another HTTP call.
 */
export interface FenergoJourneyDetails {
  journeyInstanceId?: string;
  entityId?: string;
  journeyStatus?: string;
  raw: unknown;
}

function firstNonEmptyString(record: Record<string, unknown>, candidateKeys: string[]): string | undefined {
  for (const candidateKey of candidateKeys) {
    const candidateValue = record[candidateKey];
    if (typeof candidateValue === 'string' && candidateValue.trim() !== '') {
      return candidateValue.trim();
    }
  }
  return undefined;
}

/**
 * HTTP client for the Fenergo Journey Query API. Builds the request URL as
 * `<FENERGO_BASE_URL>/<RelativeUrl>` and encapsulates timeout and error
 * handling behind {@link JourneyQueryError}.
 *
 * NOTE: authentication (e.g. an OAuth2 bearer token) is intentionally out of
 * scope for this generic service and must be added per environment. Never log
 * the Authorization header if you add one.
 */
export class FenergoJourneyClient {
  constructor(
    private readonly baseUrl: string,
    private readonly timeoutMs: number,
    private readonly logger: StructuredLogger,
  ) {
    if (!baseUrl) {
      throw new Error('FenergoJourneyClient requires a non-empty base URL');
    }
  }

  async getJourneyDetails(relativeUrl: string, correlationId?: string): Promise<FenergoJourneyDetails> {
    const requestUrl = this.buildRequestUrl(relativeUrl);
    this.logger.info({ correlationId }, 'Journey Query request started');

    let response: Response;
    try {
      response = await fetch(requestUrl, {
        method: 'GET',
        headers: { accept: 'application/json' },
        signal: AbortSignal.timeout(this.timeoutMs),
      });
    } catch (networkError) {
      this.logger.error({ correlationId }, 'Journey Query request failed');
      throw new JourneyQueryError(
        `Journey Query request failed: ${(networkError as Error).message}`,
        undefined,
        { cause: networkError },
      );
    }

    if (!response.ok) {
      this.logger.error({ correlationId, statusCode: response.status }, 'Journey Query request failed');
      throw new JourneyQueryError(`Journey Query returned HTTP ${response.status}`, response.status);
    }

    let responseBody: unknown;
    try {
      responseBody = await response.json();
    } catch (parseError) {
      this.logger.error({ correlationId }, 'Journey Query request failed');
      throw new JourneyQueryError('Journey Query returned a non-JSON response body', response.status, {
        cause: parseError,
      });
    }

    this.logger.info({ correlationId, statusCode: response.status }, 'Journey Query response received');
    return this.toJourneyDetails(responseBody);
  }

  private buildRequestUrl(relativeUrl: string): string {
    const trimmedBaseUrl = this.baseUrl.replace(/\/+$/, '');
    const trimmedRelativeUrl = relativeUrl.replace(/^\/+/, '');
    return `${trimmedBaseUrl}/${trimmedRelativeUrl}`;
  }

  private toJourneyDetails(responseBody: unknown): FenergoJourneyDetails {
    const responseRecord =
      typeof responseBody === 'object' && responseBody !== null
        ? (responseBody as Record<string, unknown>)
        : {};
    return {
      journeyInstanceId: firstNonEmptyString(responseRecord, [
        'journeyInstanceId',
        'JourneyInstanceId',
        'journeyId',
        'JourneyId',
        'id',
        'Id',
      ]),
      entityId: firstNonEmptyString(responseRecord, ['entityId', 'EntityId']),
      journeyStatus: firstNonEmptyString(responseRecord, ['status', 'Status', 'journeyStatus', 'JourneyStatus']),
      raw: responseBody,
    };
  }
}
