import crypto from 'node:crypto';

/** Exactly 64 lowercase hex characters — a SHA-256 digest in hex form. */
const HEX_SIGNATURE_PATTERN = /^[0-9a-f]{64}$/;

/**
 * Validates Fenergo webhook HMAC signatures (header: x-fenx-signature).
 *
 * CRITICAL: the HMAC is computed over the EXACT raw HTTP body bytes as
 * received on the wire. Never compute it over JSON.stringify(request.body),
 * a re-serialized object, or any trimmed/pretty-printed variant — any change
 * to whitespace, line endings, or property order produces a different
 * signature. The secret is used as raw UTF-8 bytes (it is NOT hashed first).
 *
 * Fenergo sends the digest as UPPERCASE hex, usually prefixed with "sha256=".
 * Both the prefix and the hex case are normalized before a constant-time
 * comparison (crypto.timingSafeEqual).
 *
 * This class never logs and never exposes the secret.
 */
export class FenergoSignatureService {
  private readonly secretKeyBytes: Buffer;

  constructor(webhookSecret: string) {
    if (!webhookSecret) {
      throw new Error('FenergoSignatureService requires a non-empty webhook secret');
    }
    this.secretKeyBytes = Buffer.from(webhookSecret, 'utf8');
  }

  /** HMAC-SHA256 of the exact raw body, returned as lowercase hex. */
  createSignature(rawBody: Buffer | string): string {
    const rawBodyBytes = typeof rawBody === 'string' ? Buffer.from(rawBody, 'utf8') : rawBody;
    return crypto.createHmac('sha256', this.secretKeyBytes).update(rawBodyBytes).digest('hex');
  }

  /**
   * Constant-time validation of the received signature header against the
   * exact raw request body. Returns false (never throws) for any malformed,
   * missing, or mismatched input.
   */
  isValidSignature(
    rawBody: Buffer | string | undefined,
    signatureHeader: string | string[] | undefined,
  ): boolean {
    if (rawBody === undefined || rawBody === null) {
      return false;
    }
    const rawBodyBytes = typeof rawBody === 'string' ? Buffer.from(rawBody, 'utf8') : rawBody;
    if (rawBodyBytes.length === 0) {
      return false;
    }
    if (typeof signatureHeader !== 'string' || signatureHeader.trim() === '') {
      return false;
    }

    const receivedSignatureHex = signatureHeader.trim().replace(/^sha256=/i, '').trim().toLowerCase();
    // Pre-validate before Buffer.from(hex): Node silently truncates invalid hex,
    // which would defeat the length guarantee timingSafeEqual relies on.
    if (!HEX_SIGNATURE_PATTERN.test(receivedSignatureHex)) {
      return false;
    }

    const calculatedSignatureHex = this.createSignature(rawBodyBytes);
    return crypto.timingSafeEqual(
      Buffer.from(receivedSignatureHex, 'hex'),
      Buffer.from(calculatedSignatureHex, 'hex'),
    );
  }
}
