import type { JourneyEndStatusEvent, JourneyEndStatusProcessor } from '../types/journeyTypes';
import type { StructuredLogger } from '../types/loggerTypes';

/**
 * Default downstream processor: logs the terminal event and nothing else.
 * Replace via dependency injection (see buildApp overrides) with a Kafka
 * producer, database writer, CRM update, SMTP notifier, or REST client —
 * the controller and webhook service never change.
 */
export class LoggingJourneyEndStatusProcessor implements JourneyEndStatusProcessor {
  constructor(private readonly logger: StructuredLogger) {}

  async process(event: JourneyEndStatusEvent): Promise<void> {
    this.logger.info(
      {
        notificationId: event.notificationId,
        journeyInstanceId: event.journeyInstanceId,
        entityId: event.entityId,
        terminalStatus: event.status,
        eventType: event.eventType,
        tenantId: event.tenantId,
        correlationId: event.correlationId,
        causationId: event.causationId,
      },
      'Journey end status event delivered to default logging processor',
    );
  }
}
