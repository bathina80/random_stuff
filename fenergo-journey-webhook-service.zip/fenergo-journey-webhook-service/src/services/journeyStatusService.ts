import type { FenergoJourneyClient } from './fenergoJourneyClient';
import { JourneyStatusProcessingError } from '../types/errors';
import type { JourneyEndStatusEvent, JourneyEndStatusProcessor } from '../types/journeyTypes';
import type { StructuredLogger } from '../types/loggerTypes';
import type { IdempotencyStore } from '../utils/idempotencyStore';

export type TerminalEventOutcome = 'processed' | 'duplicate';

/**
 * Orchestrates one terminal journey event:
 *
 *   1. duplicate check (idempotency store, keyed by notification Id)
 *   2. optional Journey Query enrichment (fills journeyInstanceId / entityId
 *      when the notification payload did not carry them)
 *   3. downstream processing via JourneyEndStatusProcessor
 *   4. mark processed — ONLY after successful processing
 *
 * A failure in steps 2–3 leaves the notification unmarked, so a Fenergo retry
 * of the same notification will be processed again (at-least-once semantics).
 */
export class JourneyStatusService {
  constructor(
    private readonly idempotencyStore: IdempotencyStore,
    private readonly journeyEndStatusProcessor: JourneyEndStatusProcessor,
    private readonly logger: StructuredLogger,
    private readonly journeyClient?: FenergoJourneyClient,
  ) {}

  async handleTerminalEvent(event: JourneyEndStatusEvent, relativeUrl?: string): Promise<TerminalEventOutcome> {
    if (await this.idempotencyStore.hasProcessed(event.notificationId)) {
      this.logger.info(
        { notificationId: event.notificationId, eventType: event.eventType },
        'Duplicate Fenergo notification ignored',
      );
      return 'duplicate';
    }

    const processingStartedAt = Date.now();
    this.logger.info(
      {
        notificationId: event.notificationId,
        terminalStatus: event.status,
        eventType: event.eventType,
        journeyInstanceId: event.journeyInstanceId,
        tenantId: event.tenantId,
        correlationId: event.correlationId,
      },
      'Journey end status processing started',
    );

    let enrichedEvent = event;
    if (this.journeyClient && relativeUrl && (!event.journeyInstanceId || !event.entityId)) {
      const journeyDetails = await this.journeyClient.getJourneyDetails(relativeUrl, event.correlationId);
      enrichedEvent = {
        ...event,
        journeyInstanceId: event.journeyInstanceId ?? journeyDetails.journeyInstanceId,
        entityId: event.entityId ?? journeyDetails.entityId,
      };
    }

    try {
      await this.journeyEndStatusProcessor.process(enrichedEvent);
    } catch (processingFailure) {
      throw new JourneyStatusProcessingError(
        `Downstream processing failed for notification ${event.notificationId}`,
        { cause: processingFailure },
      );
    }

    await this.idempotencyStore.markProcessed(event.notificationId);
    this.logger.info(
      {
        notificationId: event.notificationId,
        terminalStatus: enrichedEvent.status,
        journeyInstanceId: enrichedEvent.journeyInstanceId,
        processingDurationMs: Date.now() - processingStartedAt,
      },
      'Journey end status processed successfully',
    );
    return 'processed';
  }
}
