import type { JourneyStatusService } from './journeyStatusService';
import { InvalidWebhookPayloadError } from '../types/errors';
import type {
  NormalizedFenergoNotification,
  NormalizedWebhookRequest,
  WebhookProcessingSummary,
} from '../types/fenergoWebhookTypes';
import type { JourneyEndStatusEvent, JourneyTerminalStatus } from '../types/journeyTypes';
import type { StructuredLogger } from '../types/loggerTypes';

/** The only event types this service acts on; everything else is safely ignored. */
const SUPPORTED_EVENT_STATUS_BY_TYPE: Record<string, JourneyTerminalStatus> = {
  'journey:instancecompleted': 'COMPLETED',
  'journey:instancecancelled': 'CANCELLED',
};

export function resolveTerminalStatus(eventType: string): JourneyTerminalStatus | undefined {
  return SUPPORTED_EVENT_STATUS_BY_TYPE[eventType.trim().toLowerCase()];
}

function asRecord(candidateValue: unknown): Record<string, unknown> | undefined {
  if (typeof candidateValue === 'object' && candidateValue !== null && !Array.isArray(candidateValue)) {
    return candidateValue as Record<string, unknown>;
  }
  return undefined;
}

function asNonEmptyString(candidateValue: unknown): string | undefined {
  if (typeof candidateValue === 'string' && candidateValue.trim() !== '') {
    return candidateValue.trim();
  }
  return undefined;
}

function firstNonEmptyString(record: Record<string, unknown>, candidateKeys: string[]): string | undefined {
  for (const candidateKey of candidateKeys) {
    const foundValue = asNonEmptyString(record[candidateKey]);
    if (foundValue !== undefined) {
      return foundValue;
    }
  }
  return undefined;
}

/**
 * Normalizes ONE notification object — PascalCase (Id/EventType/RelativeUrl/…)
 * or camelCase (id/eventType/url/…) — into the single internal model.
 * Throws InvalidWebhookPayloadError when the mandatory Id or EventType
 * (either casing) is absent.
 */
export function normalizeSingleNotification(
  candidateNotification: unknown,
  batchId?: string,
): NormalizedFenergoNotification {
  const notificationRecord = asRecord(candidateNotification);
  if (!notificationRecord) {
    throw new InvalidWebhookPayloadError('Each notification must be a JSON object');
  }

  const notificationId = asNonEmptyString(notificationRecord.Id) ?? asNonEmptyString(notificationRecord.id);
  if (!notificationId) {
    throw new InvalidWebhookPayloadError('Notification is missing its "Id"/"id" field');
  }

  const eventType =
    asNonEmptyString(notificationRecord.EventType) ?? asNonEmptyString(notificationRecord.eventType);
  if (!eventType) {
    throw new InvalidWebhookPayloadError('Notification is missing its "EventType"/"eventType" field');
  }

  const payloadValue = 'Payload' in notificationRecord ? notificationRecord.Payload : notificationRecord.payload;

  return {
    notificationId,
    eventType,
    tenantId: asNonEmptyString(notificationRecord.TenantId) ?? asNonEmptyString(notificationRecord.tenantId),
    relativeUrl: asNonEmptyString(notificationRecord.RelativeUrl) ?? asNonEmptyString(notificationRecord.url),
    payload: asRecord(payloadValue) ?? null,
    occurredAt: asNonEmptyString(notificationRecord.When) ?? asNonEmptyString(notificationRecord.when),
    correlationId:
      asNonEmptyString(notificationRecord.CorrelationId) ?? asNonEmptyString(notificationRecord.correlationId),
    causationId:
      asNonEmptyString(notificationRecord.CausationId) ?? asNonEmptyString(notificationRecord.causationId),
    batchId,
  };
}

/**
 * Normalizes a full webhook HTTP body — either a single notification (both
 * casings) or a batch envelope { batchId, notifications[], moreAvailable } —
 * into one internal request model. `moreAvailable` is metadata only; this
 * service never polls for additional notifications.
 */
export function normalizeWebhookPayload(parsedBody: unknown): NormalizedWebhookRequest {
  const bodyRecord = asRecord(parsedBody);
  if (!bodyRecord) {
    throw new InvalidWebhookPayloadError('Webhook body must be a JSON object');
  }

  if ('notifications' in bodyRecord) {
    const notificationsValue = bodyRecord.notifications;
    if (!Array.isArray(notificationsValue)) {
      throw new InvalidWebhookPayloadError('"notifications" must be an array');
    }
    const batchId = asNonEmptyString(bodyRecord.batchId) ?? asNonEmptyString(bodyRecord.BatchId);
    const moreAvailable = typeof bodyRecord.moreAvailable === 'boolean' ? bodyRecord.moreAvailable : undefined;
    return {
      notifications: notificationsValue.map((notificationCandidate) =>
        normalizeSingleNotification(notificationCandidate, batchId),
      ),
      batchId,
      moreAvailable,
    };
  }

  return { notifications: [normalizeSingleNotification(bodyRecord)] };
}

/**
 * Maps a normalized notification to the internal domain event. Journey and
 * entity identifiers are read defensively from the notification payload using
 * commonly seen key casings; missing values may later be filled by the
 * Journey Query client. Field names must be confirmed against a real Fenergo
 * lower environment.
 */
export function toJourneyEndStatusEvent(
  notification: NormalizedFenergoNotification,
  terminalStatus: JourneyTerminalStatus,
): JourneyEndStatusEvent {
  const payloadRecord = notification.payload ?? {};
  return {
    notificationId: notification.notificationId,
    journeyInstanceId: firstNonEmptyString(payloadRecord, [
      'journeyInstanceId',
      'JourneyInstanceId',
      'journeyId',
      'JourneyId',
    ]),
    entityId: firstNonEmptyString(payloadRecord, ['entityId', 'EntityId']),
    status: terminalStatus,
    eventType: notification.eventType,
    occurredAt: notification.occurredAt,
    tenantId: notification.tenantId,
    correlationId: notification.correlationId,
    causationId: notification.causationId,
  };
}

/**
 * Single business-logic path for BOTH single-notification and batch
 * deliveries: normalize first, then run every notification through the same
 * supported-event filter and terminal-event handling.
 */
export class FenergoJourneyWebhookService {
  constructor(
    private readonly journeyStatusService: JourneyStatusService,
    private readonly logger: StructuredLogger,
  ) {}

  async handleWebhookPayload(parsedBody: unknown): Promise<WebhookProcessingSummary> {
    const normalizedRequest = normalizeWebhookPayload(parsedBody);
    const processingSummary: WebhookProcessingSummary = {
      received: normalizedRequest.notifications.length,
      processed: 0,
      duplicates: 0,
      ignored: 0,
      batchId: normalizedRequest.batchId,
      moreAvailable: normalizedRequest.moreAvailable,
    };

    for (const notification of normalizedRequest.notifications) {
      const terminalStatus = resolveTerminalStatus(notification.eventType);
      if (!terminalStatus) {
        this.logger.info(
          {
            notificationId: notification.notificationId,
            eventType: notification.eventType,
            batchId: notification.batchId,
          },
          'Unsupported Fenergo event ignored',
        );
        processingSummary.ignored += 1;
        continue;
      }

      this.logger.info(
        {
          notificationId: notification.notificationId,
          eventType: notification.eventType,
          terminalStatus,
          tenantId: notification.tenantId,
          correlationId: notification.correlationId,
          causationId: notification.causationId,
          batchId: notification.batchId,
        },
        'Journey terminal event received',
      );

      const journeyEndStatusEvent = toJourneyEndStatusEvent(notification, terminalStatus);
      const terminalEventOutcome = await this.journeyStatusService.handleTerminalEvent(
        journeyEndStatusEvent,
        notification.relativeUrl,
      );
      if (terminalEventOutcome === 'duplicate') {
        processingSummary.duplicates += 1;
      } else {
        processingSummary.processed += 1;
      }
    }

    return processingSummary;
  }
}
