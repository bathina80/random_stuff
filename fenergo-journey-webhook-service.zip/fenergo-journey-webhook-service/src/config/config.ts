/**
 * Environment-variable driven configuration with fail-fast validation.
 * No secret values are ever logged; validation errors name the missing
 * variable but never echo a value.
 */
export interface AppConfig {
  port: number;
  host: string;
  logLevel: string;
  nodeEnv: string;
  isLocalEnvironment: boolean;
  /** Base URL for Fenergo Journey Query calls. Optional in local only. */
  fenergoBaseUrl: string | undefined;
  /** HMAC secret for webhook signature validation. Required whenever validation is enabled. */
  fenergoWebhookSecret: string | undefined;
  journeyWebhookEnabled: boolean;
  /**
   * Effective signature-validation flag. A non-local environment ALWAYS
   * validates: FENERGO_SIGNATURE_VALIDATION_ENABLED=false is honored only when
   * NODE_ENV=local.
   */
  signatureValidationEnabled: boolean;
  journeyQueryTimeoutMs: number;
}

function parseBooleanFlag(rawValue: string | undefined, defaultValue: boolean): boolean {
  if (rawValue === undefined || rawValue.trim() === '') {
    return defaultValue;
  }
  return rawValue.trim().toLowerCase() === 'true';
}

function parsePositiveInteger(variableName: string, rawValue: string | undefined, defaultValue: number): number {
  if (rawValue === undefined || rawValue.trim() === '') {
    return defaultValue;
  }
  const parsedValue = Number.parseInt(rawValue, 10);
  if (!Number.isInteger(parsedValue) || parsedValue <= 0) {
    throw new Error(`Configuration error: ${variableName} must be a positive integer`);
  }
  return parsedValue;
}

export function loadConfig(environmentVariables: NodeJS.ProcessEnv = process.env): AppConfig {
  const nodeEnv = (environmentVariables.NODE_ENV ?? 'local').trim().toLowerCase() || 'local';
  const isLocalEnvironment = nodeEnv === 'local';

  const requestedSignatureValidation = parseBooleanFlag(
    environmentVariables.FENERGO_SIGNATURE_VALIDATION_ENABLED,
    true,
  );
  // Security invariant: the local-development bypass can never leak into any
  // other environment. Outside NODE_ENV=local the flag is ignored.
  const signatureValidationEnabled = isLocalEnvironment ? requestedSignatureValidation : true;

  const fenergoWebhookSecret = environmentVariables.FENERGO_WEBHOOK_SECRET?.trim() || undefined;
  const fenergoBaseUrl = environmentVariables.FENERGO_BASE_URL?.trim() || undefined;

  if (!isLocalEnvironment) {
    const missingVariableNames: string[] = [];
    if (!fenergoWebhookSecret) {
      missingVariableNames.push('FENERGO_WEBHOOK_SECRET');
    }
    if (!fenergoBaseUrl) {
      missingVariableNames.push('FENERGO_BASE_URL');
    }
    if (missingVariableNames.length > 0) {
      throw new Error(
        `Configuration error: missing required environment variables for "${nodeEnv}": ${missingVariableNames.join(', ')}`,
      );
    }
  }

  if (signatureValidationEnabled && !fenergoWebhookSecret) {
    throw new Error(
      'Configuration error: FENERGO_WEBHOOK_SECRET is required while signature validation is enabled. ' +
        'For local development only, you may set NODE_ENV=local and FENERGO_SIGNATURE_VALIDATION_ENABLED=false.',
    );
  }

  const port = parsePositiveInteger('PORT', environmentVariables.PORT, 3000);
  if (port > 65535) {
    throw new Error('Configuration error: PORT must be between 1 and 65535');
  }

  return {
    port,
    host: environmentVariables.HOST?.trim() || '0.0.0.0',
    logLevel: environmentVariables.LOG_LEVEL?.trim() || 'info',
    nodeEnv,
    isLocalEnvironment,
    fenergoBaseUrl,
    fenergoWebhookSecret,
    journeyWebhookEnabled: parseBooleanFlag(environmentVariables.FENERGO_JOURNEY_WEBHOOK_ENABLED, true),
    signatureValidationEnabled,
    journeyQueryTimeoutMs: parsePositiveInteger(
      'FENERGO_JOURNEY_QUERY_TIMEOUT_MS',
      environmentVariables.FENERGO_JOURNEY_QUERY_TIMEOUT_MS,
      5000,
    ),
  };
}
