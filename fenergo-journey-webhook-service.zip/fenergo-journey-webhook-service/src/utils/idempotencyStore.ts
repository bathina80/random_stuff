/**
 * Idempotency guard keyed by the Fenergo notification Id.
 *
 * The Fenergo HMAC scheme carries no timestamp and therefore no replay
 * protection; combined with at-least-once webhook delivery this store is what
 * keeps duplicate deliveries from re-triggering downstream side effects.
 */
export interface IdempotencyStore {
  hasProcessed(notificationId: string): Promise<boolean>;
  markProcessed(notificationId: string): Promise<void>;
}

/**
 * In-memory implementation — LOCAL DEVELOPMENT / SINGLE-INSTANCE ONLY.
 *
 * Limitations (deliberate, documented):
 * - State is lost on restart, so previously processed notifications will be
 *   reprocessed after a redeploy.
 * - Not shared across replicas: with more than one instance behind a load
 *   balancer, duplicates delivered to different instances are NOT detected.
 * - Entries are evicted oldest-first once `maximumEntries` is reached.
 *
 * Production deployments should replace this with a shared store (e.g. Redis
 * SETNX with TTL, or a database unique constraint on notification Id).
 */
export class InMemoryIdempotencyStore implements IdempotencyStore {
  private readonly processedNotificationIds = new Set<string>();

  constructor(private readonly maximumEntries: number = 10_000) {
    if (!Number.isInteger(maximumEntries) || maximumEntries <= 0) {
      throw new Error('InMemoryIdempotencyStore requires a positive maximumEntries');
    }
  }

  async hasProcessed(notificationId: string): Promise<boolean> {
    return this.processedNotificationIds.has(notificationId);
  }

  async markProcessed(notificationId: string): Promise<void> {
    if (
      !this.processedNotificationIds.has(notificationId) &&
      this.processedNotificationIds.size >= this.maximumEntries
    ) {
      const oldestNotificationId = this.processedNotificationIds.values().next().value;
      if (oldestNotificationId !== undefined) {
        this.processedNotificationIds.delete(oldestNotificationId);
      }
    }
    this.processedNotificationIds.add(notificationId);
  }
}
