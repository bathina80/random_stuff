/**
 * Wire-level shapes of Fenergo Event Notification webhook deliveries.
 *
 * Fenergo has been observed delivering BOTH property-name conventions, so this
 * service accepts both and folds them into a single internal model
 * ({@link NormalizedFenergoNotification}). Field availability must be confirmed
 * against a real Fenergo lower environment before production use.
 */

/** Single notification using PascalCase property names. */
export interface FenergoPascalCaseNotification {
  Id: string;
  TenantId?: string;
  EventType: string;
  RelativeUrl?: string;
  Payload?: Record<string, unknown> | null;
  When?: string;
  CorrelationId?: string;
  CausationId?: string;
}

/** Single notification using camelCase property names. */
export interface FenergoCamelCaseNotification {
  id: string;
  tenantId?: string;
  eventType: string;
  url?: string;
  payload?: Record<string, unknown> | null;
  when?: string;
  correlationId?: string;
  causationId?: string;
}

/** Batch envelope. `moreAvailable` is treated as metadata only — this service never polls. */
export interface FenergoNotificationBatch {
  batchId?: string;
  notifications: unknown[];
  moreAvailable?: boolean;
}

/** The single internal notification model every wire shape is normalized into. */
export interface NormalizedFenergoNotification {
  notificationId: string;
  eventType: string;
  tenantId?: string;
  /** Relative Fenergo API path (e.g. journey query URL) taken from RelativeUrl / url. */
  relativeUrl?: string;
  payload: Record<string, unknown> | null;
  occurredAt?: string;
  correlationId?: string;
  causationId?: string;
  batchId?: string;
}

/** Result of normalizing one webhook HTTP request. */
export interface NormalizedWebhookRequest {
  notifications: NormalizedFenergoNotification[];
  batchId?: string;
  moreAvailable?: boolean;
}

/** Outcome summary returned in the 202 response body. */
export interface WebhookProcessingSummary {
  received: number;
  processed: number;
  duplicates: number;
  ignored: number;
  batchId?: string;
  moreAvailable?: boolean;
}
