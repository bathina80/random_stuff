/**
 * Minimal structural logger contract so services stay framework-neutral.
 * Fastify's built-in Pino logger satisfies this interface directly.
 */
export interface StructuredLogger {
  debug(mergingObject: object, message?: string): void;
  info(mergingObject: object, message?: string): void;
  warn(mergingObject: object, message?: string): void;
  error(mergingObject: object, message?: string): void;
}
