/** Raised when the x-fenx-signature header does not match the received raw body. */
export class InvalidWebhookSignatureError extends Error {
  constructor(message = 'Invalid webhook signature') {
    super(message);
    this.name = 'InvalidWebhookSignatureError';
  }
}

/** Raised when the webhook body cannot be normalized into Fenergo notifications. */
export class InvalidWebhookPayloadError extends Error {
  constructor(message = 'Invalid webhook payload') {
    super(message);
    this.name = 'InvalidWebhookPayloadError';
  }
}

/** Raised when the Fenergo Journey Query API call fails (network, timeout, non-2xx, non-JSON). */
export class JourneyQueryError extends Error {
  readonly statusCode: number | undefined;

  constructor(message: string, statusCode?: number, options?: { cause?: unknown }) {
    super(message, options);
    this.name = 'JourneyQueryError';
    this.statusCode = statusCode;
  }
}

/** Raised when the downstream JourneyEndStatusProcessor fails. */
export class JourneyStatusProcessingError extends Error {
  constructor(message: string, options?: { cause?: unknown }) {
    super(message, options);
    this.name = 'JourneyStatusProcessingError';
  }
}
