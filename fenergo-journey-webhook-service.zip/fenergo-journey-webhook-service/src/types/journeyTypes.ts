/** Terminal states this service reacts to. All other journey states are ignored. */
export type JourneyTerminalStatus = 'COMPLETED' | 'CANCELLED';

/** Internal domain event emitted when a journey reaches a terminal status. */
export interface JourneyEndStatusEvent {
  notificationId: string;
  journeyInstanceId?: string;
  entityId?: string;
  status: JourneyTerminalStatus;
  eventType: string;
  occurredAt?: string;
  tenantId?: string;
  correlationId?: string;
  causationId?: string;
}

/**
 * Downstream integration seam. Swap the default logging implementation for a
 * Kafka producer, database writer, CRM update, SMTP notifier, or REST call
 * without touching the controller or webhook service.
 */
export interface JourneyEndStatusProcessor {
  process(event: JourneyEndStatusEvent): Promise<void>;
}
