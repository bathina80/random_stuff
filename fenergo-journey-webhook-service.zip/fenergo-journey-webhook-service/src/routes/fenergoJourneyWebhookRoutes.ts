import type { FastifyInstance, FastifyRequest } from 'fastify';
import type { FenergoJourneyWebhookController } from '../controllers/fenergoJourneyWebhookController';

declare module 'fastify' {
  interface FastifyRequest {
    /** Exact bytes of the HTTP body as received on the wire — the ONLY valid HMAC input. */
    rawBody?: Buffer;
  }
}

export interface FenergoJourneyWebhookRouteOptions {
  controller: FenergoJourneyWebhookController;
}

/**
 * Registers the journey webhook route together with a ROUTE-SCOPED raw-body
 * content-type parser.
 *
 * This plugin is intentionally NOT wrapped in fastify-plugin: Fastify plugin
 * encapsulation confines the application/json parser override to the routes
 * registered inside this plugin, so the rest of the application keeps
 * Fastify's default JSON handling.
 *
 * The parser stores the untouched Buffer on request.rawBody for HMAC
 * validation and separately JSON.parses a decoded copy for request.body.
 * The raw bytes are never re-serialized, trimmed, or pretty-printed.
 */
export async function fenergoJourneyWebhookRoutes(
  fastify: FastifyInstance,
  routeOptions: FenergoJourneyWebhookRouteOptions,
): Promise<void> {
  fastify.addContentTypeParser(
    'application/json',
    { parseAs: 'buffer' },
    (request: FastifyRequest, requestBodyBytes: Buffer, done) => {
      request.rawBody = requestBodyBytes;

      if (requestBodyBytes.length === 0) {
        const emptyBodyError = new Error('Webhook body must not be empty') as Error & { statusCode?: number };
        emptyBodyError.statusCode = 400;
        done(emptyBodyError, undefined);
        return;
      }

      try {
        done(null, JSON.parse(requestBodyBytes.toString('utf8')) as unknown);
      } catch {
        const malformedJsonError = new Error('Malformed JSON in webhook body') as Error & { statusCode?: number };
        malformedJsonError.statusCode = 400;
        done(malformedJsonError, undefined);
      }
    },
  );

  fastify.post('/api/webhooks/fenergo/journey-status', (request, reply) =>
    routeOptions.controller.handleJourneyStatusWebhook(request, reply),
  );
}
