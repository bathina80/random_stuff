import fastify, { type FastifyInstance } from 'fastify';
import type { AppConfig } from './config/config';
import { FenergoJourneyWebhookController } from './controllers/fenergoJourneyWebhookController';
import { fenergoJourneyWebhookRoutes } from './routes/fenergoJourneyWebhookRoutes';
import { FenergoJourneyClient } from './services/fenergoJourneyClient';
import { FenergoJourneyWebhookService } from './services/fenergoJourneyWebhookService';
import { FenergoSignatureService } from './services/fenergoSignatureService';
import { JourneyStatusService } from './services/journeyStatusService';
import { LoggingJourneyEndStatusProcessor } from './services/loggingJourneyEndStatusProcessor';
import type { JourneyEndStatusProcessor } from './types/journeyTypes';
import { InMemoryIdempotencyStore, type IdempotencyStore } from './utils/idempotencyStore';

/** Dependency-injection seams, primarily for tests and downstream integrations. */
export interface AppOverrides {
  idempotencyStore?: IdempotencyStore;
  journeyEndStatusProcessor?: JourneyEndStatusProcessor;
  journeyClient?: FenergoJourneyClient;
}

export function buildApp(appConfig: AppConfig, appOverrides: AppOverrides = {}): FastifyInstance {
  const app = fastify({
    logger: {
      level: appConfig.logLevel,
      // Defense in depth: even accidental full-header logging never emits
      // credentials or the signature header value.
      redact: {
        paths: ['req.headers.authorization', 'req.headers["x-fenx-signature"]'],
        censor: '[REDACTED]',
      },
    },
  });

  if (!appConfig.signatureValidationEnabled) {
    app.log.warn('Fenergo HMAC validation disabled for local development');
  }

  const signatureService = appConfig.fenergoWebhookSecret
    ? new FenergoSignatureService(appConfig.fenergoWebhookSecret)
    : undefined;

  const journeyClient =
    appOverrides.journeyClient ??
    (appConfig.fenergoBaseUrl
      ? new FenergoJourneyClient(appConfig.fenergoBaseUrl, appConfig.journeyQueryTimeoutMs, app.log)
      : undefined);

  const idempotencyStore = appOverrides.idempotencyStore ?? new InMemoryIdempotencyStore();
  const journeyEndStatusProcessor =
    appOverrides.journeyEndStatusProcessor ?? new LoggingJourneyEndStatusProcessor(app.log);

  const journeyStatusService = new JourneyStatusService(
    idempotencyStore,
    journeyEndStatusProcessor,
    app.log,
    journeyClient,
  );
  const webhookService = new FenergoJourneyWebhookService(journeyStatusService, app.log);
  const webhookController = new FenergoJourneyWebhookController(appConfig, webhookService, signatureService);

  // Sanitized error responses: client errors keep their message (e.g. the
  // content-type parser's "Malformed JSON in webhook body"), everything else
  // becomes an opaque 500. Stack traces are never sent to the caller.
  app.setErrorHandler((error, request, reply) => {
    const declaredStatusCode = (error as { statusCode?: number }).statusCode;
    if (typeof declaredStatusCode === 'number' && declaredStatusCode >= 400 && declaredStatusCode < 500) {
      request.log.warn({ reason: error.message, statusCode: declaredStatusCode }, 'Request rejected');
      void reply.status(declaredStatusCode).send({ error: error.message });
      return;
    }
    request.log.error({ errorName: error.name, errorMessage: error.message }, 'Fenergo webhook processing failed');
    void reply.status(500).send({ error: 'Internal server error' });
  });

  app.get('/health', async () => ({ status: 'ok' }));

  void app.register(fenergoJourneyWebhookRoutes, { controller: webhookController });

  return app;
}
