import eslintJs from '@eslint/js';
import typescriptEslint from 'typescript-eslint';

export default typescriptEslint.config(
  {
    ignores: ['dist/**', 'coverage/**', 'node_modules/**', 'scripts/**', 'eslint.config.mjs', 'vitest.config.ts'],
  },
  eslintJs.configs.recommended,
  ...typescriptEslint.configs.recommended,
  {
    rules: {
      '@typescript-eslint/no-explicit-any': 'error',
      '@typescript-eslint/no-unused-vars': ['error', { argsIgnorePattern: '^_' }],
    },
  },
);
