import type { FastifyInstance } from 'fastify';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { buildApp, type AppOverrides } from '../src/app';
import { loadConfig } from '../src/config/config';
import type { FenergoJourneyClient } from '../src/services/fenergoJourneyClient';
import type { JourneyEndStatusEvent } from '../src/types/journeyTypes';
import { createTestConfig, TEST_WEBHOOK_SECRET } from './helpers/testConfig';
import { createTestSignature } from './helpers/testSignature';

const WEBHOOK_PATH = '/api/webhooks/fenergo/journey-status';
const NOTIFICATION_ID = '00000000-0000-0000-0000-000000000001';
const TENANT_ID = '00000000-0000-0000-0000-000000000002';
const JOURNEY_INSTANCE_ID = '00000000-0000-0000-0000-000000000003';
const CORRELATION_ID = '00000000-0000-0000-0000-000000000004';
const CAUSATION_ID = '00000000-0000-0000-0000-000000000005';

const openApps: FastifyInstance[] = [];

afterEach(async () => {
  await Promise.all(openApps.splice(0).map((appInstance) => appInstance.close()));
});

interface TestAppContext {
  app: FastifyInstance;
  processedEvents: JourneyEndStatusEvent[];
  processorMock: ReturnType<typeof vi.fn>;
}

function createTestApp(
  configOverrides: Parameters<typeof createTestConfig>[0] = {},
  appOverrides: AppOverrides = {},
): TestAppContext {
  const processedEvents: JourneyEndStatusEvent[] = [];
  const processorMock = vi.fn(async (event: JourneyEndStatusEvent) => {
    processedEvents.push(event);
  });
  const stubJourneyClient = {
    getJourneyDetails: vi.fn().mockResolvedValue({
      journeyInstanceId: JOURNEY_INSTANCE_ID,
      entityId: CAUSATION_ID,
      journeyStatus: 'Completed',
      raw: {},
    }),
  } as unknown as FenergoJourneyClient;

  const app = buildApp(createTestConfig(configOverrides), {
    journeyEndStatusProcessor: { process: processorMock },
    journeyClient: stubJourneyClient,
    ...appOverrides,
  });
  openApps.push(app);
  return { app, processedEvents, processorMock };
}

function pascalCaseNotification(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    Id: NOTIFICATION_ID,
    TenantId: TENANT_ID,
    EventType: 'journey:instancecompleted',
    RelativeUrl: `/journeyquery/api/journeys/${JOURNEY_INSTANCE_ID}`,
    Payload: { journeyInstanceId: JOURNEY_INSTANCE_ID },
    When: '2026-01-01T00:00:00Z',
    CorrelationId: CORRELATION_ID,
    CausationId: CAUSATION_ID,
    ...overrides,
  };
}

/** Injects the EXACT string used to compute the signature — never a re-stringified object. */
async function postSignedWebhook(app: FastifyInstance, rawBody: string, secret: string = TEST_WEBHOOK_SECRET) {
  return app.inject({
    method: 'POST',
    url: WEBHOOK_PATH,
    headers: {
      'content-type': 'application/json',
      'x-fenx-signature': createTestSignature(rawBody, secret),
    },
    payload: rawBody,
  });
}

describe('POST /api/webhooks/fenergo/journey-status — single notifications', () => {
  it('returns 202 and processes a signed PascalCase completed notification', async () => {
    const { app, processedEvents } = createTestApp();
    const rawBody = JSON.stringify(pascalCaseNotification());

    const response = await postSignedWebhook(app, rawBody);

    expect(response.statusCode).toBe(202);
    expect(response.json()).toMatchObject({ status: 'accepted', received: 1, processed: 1, duplicates: 0, ignored: 0 });
    expect(processedEvents).toHaveLength(1);
    expect(processedEvents[0]).toMatchObject({
      notificationId: NOTIFICATION_ID,
      status: 'COMPLETED',
      journeyInstanceId: JOURNEY_INSTANCE_ID,
      tenantId: TENANT_ID,
      correlationId: CORRELATION_ID,
    });
  });

  it('returns 202 and processes a signed camelCase cancelled notification', async () => {
    const { app, processedEvents } = createTestApp();
    const rawBody = JSON.stringify({
      id: NOTIFICATION_ID,
      tenantId: TENANT_ID,
      eventType: 'journey:instancecancelled',
      url: `/journeyquery/api/journeys/${JOURNEY_INSTANCE_ID}`,
      payload: { journeyInstanceId: JOURNEY_INSTANCE_ID },
      when: '2026-01-01T00:00:00Z',
      correlationId: CORRELATION_ID,
      causationId: CAUSATION_ID,
    });

    const response = await postSignedWebhook(app, rawBody);

    expect(response.statusCode).toBe(202);
    expect(response.json()).toMatchObject({ processed: 1 });
    expect(processedEvents[0]).toMatchObject({ status: 'CANCELLED' });
  });

  it('returns 202 and ignores an unsupported event type without touching the processor', async () => {
    const { app, processorMock } = createTestApp();
    const rawBody = JSON.stringify(pascalCaseNotification({ EventType: 'journey:taskcompleted' }));

    const response = await postSignedWebhook(app, rawBody);

    expect(response.statusCode).toBe(202);
    expect(response.json()).toMatchObject({ received: 1, processed: 0, ignored: 1 });
    expect(processorMock).not.toHaveBeenCalled();
  });

  it('returns 202 for a duplicate delivery and processes it only once', async () => {
    const { app, processorMock } = createTestApp();
    const rawBody = JSON.stringify(pascalCaseNotification());

    const firstResponse = await postSignedWebhook(app, rawBody);
    const secondResponse = await postSignedWebhook(app, rawBody);

    expect(firstResponse.statusCode).toBe(202);
    expect(firstResponse.json()).toMatchObject({ processed: 1, duplicates: 0 });
    expect(secondResponse.statusCode).toBe(202);
    expect(secondResponse.json()).toMatchObject({ processed: 0, duplicates: 1 });
    expect(processorMock).toHaveBeenCalledTimes(1);
  });

  it('returns 401 when the signature header is missing', async () => {
    const { app, processorMock } = createTestApp();
    const response = await app.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: { 'content-type': 'application/json' },
      payload: JSON.stringify(pascalCaseNotification()),
    });

    expect(response.statusCode).toBe(401);
    expect(processorMock).not.toHaveBeenCalled();
  });

  it('returns 401 when the signature was computed with a different secret', async () => {
    const { app } = createTestApp();
    const rawBody = JSON.stringify(pascalCaseNotification());
    const response = await postSignedWebhook(app, rawBody, 'a-different-secret-value');
    expect(response.statusCode).toBe(401);
  });

  it('returns 401 when the signature matches a different body than the one received', async () => {
    const { app } = createTestApp();
    const signedBody = JSON.stringify(pascalCaseNotification());
    const differentBody = JSON.stringify(pascalCaseNotification({ When: '2026-02-02T00:00:00Z' }));
    const response = await app.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: {
        'content-type': 'application/json',
        'x-fenx-signature': createTestSignature(signedBody, TEST_WEBHOOK_SECRET),
      },
      payload: differentBody,
    });
    expect(response.statusCode).toBe(401);
  });

  it('returns 400 for malformed JSON (signed over the exact malformed bytes) without a stack trace', async () => {
    const { app } = createTestApp();
    const malformedRawBody = '{"Id": "00000000-0000-0000-0000-000000000001", "EventType": ';
    const response = await postSignedWebhook(app, malformedRawBody);

    expect(response.statusCode).toBe(400);
    const responseBody = response.json();
    expect(responseBody).toEqual({ error: 'Malformed JSON in webhook body' });
    expect(JSON.stringify(responseBody)).not.toContain('at ');
  });

  it('returns 400 for a structurally invalid notification (missing Id)', async () => {
    const { app } = createTestApp();
    const rawBody = JSON.stringify({ EventType: 'journey:instancecompleted' });
    const response = await postSignedWebhook(app, rawBody);
    expect(response.statusCode).toBe(400);
  });

  it('returns 500 when the downstream processor fails, then 202 on the Fenergo retry', async () => {
    const { app, processorMock } = createTestApp();
    processorMock.mockRejectedValueOnce(new Error('downstream unavailable'));
    const rawBody = JSON.stringify(pascalCaseNotification());

    const failedResponse = await postSignedWebhook(app, rawBody);
    expect(failedResponse.statusCode).toBe(500);
    expect(failedResponse.json()).toEqual({ error: 'Webhook processing failed' });

    // The failed notification was NOT marked processed, so the retry succeeds.
    const retryResponse = await postSignedWebhook(app, rawBody);
    expect(retryResponse.statusCode).toBe(202);
    expect(retryResponse.json()).toMatchObject({ processed: 1, duplicates: 0 });
  });

  it('returns 202 with disabled=true when the journey webhook feature flag is off', async () => {
    const { app, processorMock } = createTestApp({ journeyWebhookEnabled: false });
    const rawBody = JSON.stringify(pascalCaseNotification());
    const response = await postSignedWebhook(app, rawBody);

    expect(response.statusCode).toBe(202);
    expect(response.json()).toMatchObject({ status: 'accepted', disabled: true });
    expect(processorMock).not.toHaveBeenCalled();
  });
});

describe('local-development signature bypass (via loadConfig)', () => {
  const baseEnvironment = {
    FENERGO_BASE_URL: 'https://fenergo-api.example.invalid',
    FENERGO_WEBHOOK_SECRET: TEST_WEBHOOK_SECRET,
    LOG_LEVEL: 'silent',
  };

  it('accepts an unsigned request ONLY when NODE_ENV=local and validation is disabled', async () => {
    const localBypassConfig = loadConfig({
      ...baseEnvironment,
      NODE_ENV: 'local',
      FENERGO_SIGNATURE_VALIDATION_ENABLED: 'false',
    });
    expect(localBypassConfig.signatureValidationEnabled).toBe(false);

    const { app } = createTestApp(localBypassConfig);
    const response = await app.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: { 'content-type': 'application/json' },
      payload: JSON.stringify(pascalCaseNotification()),
    });
    expect(response.statusCode).toBe(202);
  });

  it('a non-local environment ALWAYS validates — the disable flag is ignored', async () => {
    const productionConfig = loadConfig({
      ...baseEnvironment,
      NODE_ENV: 'production',
      FENERGO_SIGNATURE_VALIDATION_ENABLED: 'false',
    });
    expect(productionConfig.signatureValidationEnabled).toBe(true);

    const { app } = createTestApp(productionConfig);
    const unsignedResponse = await app.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: { 'content-type': 'application/json' },
      payload: JSON.stringify(pascalCaseNotification()),
    });
    expect(unsignedResponse.statusCode).toBe(401);
  });

  it('loadConfig fails fast when required configuration is missing outside local', () => {
    expect(() => loadConfig({ NODE_ENV: 'production' })).toThrow(/FENERGO_WEBHOOK_SECRET/);
    expect(() =>
      loadConfig({ NODE_ENV: 'production', FENERGO_WEBHOOK_SECRET: TEST_WEBHOOK_SECRET }),
    ).toThrow(/FENERGO_BASE_URL/);
    expect(() => loadConfig({ NODE_ENV: 'local' })).toThrow(/FENERGO_WEBHOOK_SECRET/);
    expect(() => loadConfig({ NODE_ENV: 'production', PORT: 'not-a-number' })).toThrow(/PORT/);
  });

  it('loadConfig applies defaults and honors overrides in local', () => {
    const localConfig = loadConfig({
      NODE_ENV: 'local',
      FENERGO_SIGNATURE_VALIDATION_ENABLED: 'false',
      PORT: '4100',
    });
    expect(localConfig).toMatchObject({
      port: 4100,
      host: '0.0.0.0',
      logLevel: 'info',
      nodeEnv: 'local',
      isLocalEnvironment: true,
      journeyWebhookEnabled: true,
      signatureValidationEnabled: false,
      journeyQueryTimeoutMs: 5000,
    });
  });
});

describe('POST /api/webhooks/fenergo/journey-status — batch envelopes', () => {
  const BATCH_ID = '00000000-0000-0000-0000-00000000000b';

  function batchBody(notifications: Record<string, unknown>[], moreAvailable = false): string {
    return JSON.stringify({ batchId: BATCH_ID, notifications, moreAvailable });
  }

  it('processes a batch containing completed and cancelled notifications', async () => {
    const { app, processedEvents } = createTestApp();
    const rawBody = batchBody([
      pascalCaseNotification(),
      pascalCaseNotification({
        Id: '00000000-0000-0000-0000-000000000006',
        EventType: 'journey:instancecancelled',
      }),
    ]);

    const response = await postSignedWebhook(app, rawBody);

    expect(response.statusCode).toBe(202);
    expect(response.json()).toMatchObject({ received: 2, processed: 2, duplicates: 0, ignored: 0, batchId: BATCH_ID });
    expect(processedEvents.map((processedEvent) => processedEvent.status)).toEqual(['COMPLETED', 'CANCELLED']);
  });

  it('processes a mixed batch of supported and unsupported events', async () => {
    const { app, processorMock } = createTestApp();
    const rawBody = batchBody([
      pascalCaseNotification(),
      pascalCaseNotification({ Id: '00000000-0000-0000-0000-000000000006', EventType: 'journey:taskcompleted' }),
      pascalCaseNotification({
        Id: '00000000-0000-0000-0000-000000000007',
        EventType: 'journey:integrationflowfailed',
      }),
    ]);

    const response = await postSignedWebhook(app, rawBody);

    expect(response.statusCode).toBe(202);
    expect(response.json()).toMatchObject({ received: 3, processed: 1, ignored: 2 });
    expect(processorMock).toHaveBeenCalledTimes(1);
  });

  it('detects a duplicate inside a batch (same notification Id twice)', async () => {
    const { app, processorMock } = createTestApp();
    const rawBody = batchBody([pascalCaseNotification(), pascalCaseNotification()]);

    const response = await postSignedWebhook(app, rawBody);

    expect(response.statusCode).toBe(202);
    expect(response.json()).toMatchObject({ received: 2, processed: 1, duplicates: 1 });
    expect(processorMock).toHaveBeenCalledTimes(1);
  });

  it('accepts an empty batch', async () => {
    const { app } = createTestApp();
    const response = await postSignedWebhook(app, batchBody([]));
    expect(response.statusCode).toBe(202);
    expect(response.json()).toMatchObject({ received: 0, processed: 0, duplicates: 0, ignored: 0 });
  });

  it('treats moreAvailable=true as metadata only — still 202, no polling side effects', async () => {
    const { app } = createTestApp();
    const response = await postSignedWebhook(app, batchBody([pascalCaseNotification()], true));
    expect(response.statusCode).toBe(202);
    expect(response.json()).toMatchObject({ processed: 1, moreAvailable: true });
  });

  it('processes a batch notification whose Payload is null', async () => {
    const { app, processedEvents } = createTestApp();
    const rawBody = batchBody([pascalCaseNotification({ Payload: null })]);

    const response = await postSignedWebhook(app, rawBody);

    expect(response.statusCode).toBe(202);
    expect(response.json()).toMatchObject({ processed: 1 });
    // Identifiers were filled by the (stubbed) Journey Query enrichment.
    expect(processedEvents[0]).toMatchObject({ journeyInstanceId: JOURNEY_INSTANCE_ID });
  });
});

describe('GET /health', () => {
  it('responds 200 ok', async () => {
    const { app } = createTestApp();
    const response = await app.inject({ method: 'GET', url: '/health' });
    expect(response.statusCode).toBe(200);
    expect(response.json()).toEqual({ status: 'ok' });
  });
});
