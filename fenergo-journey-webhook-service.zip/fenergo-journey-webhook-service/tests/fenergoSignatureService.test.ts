import crypto from 'node:crypto';
import { describe, expect, it } from 'vitest';
import { FenergoSignatureService } from '../src/services/fenergoSignatureService';
import { createTestSignature } from './helpers/testSignature';

const TEST_SECRET = 'test-webhook-secret-not-a-real-secret';

const SAMPLE_NOTIFICATION = {
  Id: '00000000-0000-0000-0000-000000000001',
  TenantId: '00000000-0000-0000-0000-000000000002',
  EventType: 'journey:instancecompleted',
  RelativeUrl: '/journeyquery/api/journeys/00000000-0000-0000-0000-000000000003',
  Payload: { journeyInstanceId: '00000000-0000-0000-0000-000000000003' },
  When: '2026-01-01T00:00:00Z',
  CorrelationId: '00000000-0000-0000-0000-000000000004',
  CausationId: '00000000-0000-0000-0000-000000000005',
};

describe('FenergoSignatureService', () => {
  const signatureService = new FenergoSignatureService(TEST_SECRET);
  const compactRawBody = JSON.stringify(SAMPLE_NOTIFICATION);

  it('scenario 1: accepts a valid UPPERCASE-hex signature with the sha256= prefix', () => {
    const signatureHeader = createTestSignature(compactRawBody, TEST_SECRET);
    expect(signatureHeader.startsWith('sha256=')).toBe(true);
    expect(signatureHeader.slice('sha256='.length)).toMatch(/^[0-9A-F]{64}$/);
    expect(signatureService.isValidSignature(compactRawBody, signatureHeader)).toBe(true);
  });

  it('scenario 2: accepts a valid lowercase-hex signature without any prefix', () => {
    const lowercaseUnprefixedSignature = signatureService.createSignature(compactRawBody);
    expect(signatureService.isValidSignature(compactRawBody, lowercaseUnprefixedSignature)).toBe(true);
  });

  it('scenario 3: accepts a mixed-case prefix and surrounding whitespace', () => {
    const digestHex = signatureService.createSignature(compactRawBody).toUpperCase();
    expect(signatureService.isValidSignature(compactRawBody, `  SHA256=${digestHex}  `)).toBe(true);
  });

  it('scenario 4: rejects a signature produced with a different secret', () => {
    const foreignSignature = createTestSignature(compactRawBody, 'a-different-secret-value');
    expect(signatureService.isValidSignature(compactRawBody, foreignSignature)).toBe(false);
  });

  it('scenario 5: rejects when a single byte of the body changes after signing', () => {
    const signatureHeader = createTestSignature(compactRawBody, TEST_SECRET);
    const tamperedRawBody = compactRawBody.replace('journey:instancecompleted', 'journey:instancecancelled');
    expect(signatureService.isValidSignature(tamperedRawBody, signatureHeader)).toBe(false);
  });

  it('scenario 6: rejects a signature computed over pretty-printed JSON when the compact body was received', () => {
    // This documents the raw-body rule: parsing and re-stringifying (or
    // pretty-printing) the body changes the bytes and breaks the HMAC.
    const prettyPrintedBody = JSON.stringify(SAMPLE_NOTIFICATION, null, 2);
    const signatureOverPrettyBody = createTestSignature(prettyPrintedBody, TEST_SECRET);
    expect(signatureService.isValidSignature(compactRawBody, signatureOverPrettyBody)).toBe(false);
    // ...and the same signature IS valid for the exact bytes it was computed over.
    expect(signatureService.isValidSignature(prettyPrintedBody, signatureOverPrettyBody)).toBe(true);
  });

  it('scenario 7: rejects a missing, empty, or array-valued signature header', () => {
    expect(signatureService.isValidSignature(compactRawBody, undefined)).toBe(false);
    expect(signatureService.isValidSignature(compactRawBody, '')).toBe(false);
    expect(signatureService.isValidSignature(compactRawBody, '   ')).toBe(false);
    const validSignature = createTestSignature(compactRawBody, TEST_SECRET);
    expect(signatureService.isValidSignature(compactRawBody, [validSignature, validSignature])).toBe(false);
  });

  it('scenario 8: rejects malformed hex (wrong length or non-hex characters) without throwing', () => {
    const validDigestHex = signatureService.createSignature(compactRawBody);
    expect(signatureService.isValidSignature(compactRawBody, `sha256=${validDigestHex.slice(0, 63)}`)).toBe(false);
    expect(signatureService.isValidSignature(compactRawBody, `sha256=${validDigestHex}00`)).toBe(false);
    expect(
      signatureService.isValidSignature(compactRawBody, `sha256=zz${validDigestHex.slice(2)}`),
    ).toBe(false);
    expect(signatureService.isValidSignature(compactRawBody, 'sha256=not-a-signature')).toBe(false);
  });

  it('scenario 9: rejects an empty or missing raw body', () => {
    const signatureOverEmptyBody = createTestSignature('', TEST_SECRET);
    expect(signatureService.isValidSignature('', signatureOverEmptyBody)).toBe(false);
    expect(signatureService.isValidSignature(Buffer.alloc(0), signatureOverEmptyBody)).toBe(false);
    expect(signatureService.isValidSignature(undefined, signatureOverEmptyBody)).toBe(false);
  });

  it('scenario 10: validates identically for Buffer and string raw bodies with the same bytes', () => {
    const signatureHeader = createTestSignature(compactRawBody, TEST_SECRET);
    expect(signatureService.isValidSignature(Buffer.from(compactRawBody, 'utf8'), signatureHeader)).toBe(true);
    expect(signatureService.isValidSignature(compactRawBody, signatureHeader)).toBe(true);
  });

  it('scenario 11: createSignature is deterministic lowercase 64-char hex matching node:crypto directly', () => {
    const calculatedSignature = signatureService.createSignature(compactRawBody);
    expect(calculatedSignature).toMatch(/^[0-9a-f]{64}$/);
    const referenceSignature = crypto
      .createHmac('sha256', Buffer.from(TEST_SECRET, 'utf8'))
      .update(Buffer.from(compactRawBody, 'utf8'))
      .digest('hex');
    expect(calculatedSignature).toBe(referenceSignature);
    expect(signatureService.createSignature(compactRawBody)).toBe(calculatedSignature);
  });

  it('requires a non-empty secret at construction time', () => {
    expect(() => new FenergoSignatureService('')).toThrow();
  });
});
