import { describe, expect, it, vi } from 'vitest';
import type { FenergoJourneyClient } from '../src/services/fenergoJourneyClient';
import { JourneyStatusService } from '../src/services/journeyStatusService';
import { JourneyQueryError, JourneyStatusProcessingError } from '../src/types/errors';
import type { JourneyEndStatusEvent } from '../src/types/journeyTypes';
import { InMemoryIdempotencyStore } from '../src/utils/idempotencyStore';

const NOTIFICATION_ID = '00000000-0000-0000-0000-000000000001';
const JOURNEY_INSTANCE_ID = '00000000-0000-0000-0000-000000000003';
const ENTITY_ID = '00000000-0000-0000-0000-000000000005';
const RELATIVE_URL = `/journeyquery/api/journeys/${JOURNEY_INSTANCE_ID}`;

const silentLogger = { debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn() };

function terminalEvent(eventOverrides: Partial<JourneyEndStatusEvent> = {}): JourneyEndStatusEvent {
  return {
    notificationId: NOTIFICATION_ID,
    status: 'COMPLETED',
    eventType: 'journey:instancecompleted',
    ...eventOverrides,
  };
}

function stubJourneyClient(): FenergoJourneyClient {
  return {
    getJourneyDetails: vi.fn().mockResolvedValue({
      journeyInstanceId: JOURNEY_INSTANCE_ID,
      entityId: ENTITY_ID,
      journeyStatus: 'Completed',
      raw: {},
    }),
  } as unknown as FenergoJourneyClient;
}

describe('JourneyStatusService idempotency ordering', () => {
  it('scenario 1: processes a first-time notification and marks it only after success', async () => {
    const callOrder: string[] = [];
    const idempotencyStore = {
      hasProcessed: vi.fn(async () => {
        callOrder.push('hasProcessed');
        return false;
      }),
      markProcessed: vi.fn(async () => {
        callOrder.push('markProcessed');
      }),
    };
    const processor = {
      process: vi.fn(async () => {
        callOrder.push('process');
      }),
    };
    const journeyStatusService = new JourneyStatusService(idempotencyStore, processor, silentLogger);

    const terminalEventOutcome = await journeyStatusService.handleTerminalEvent(terminalEvent());

    expect(terminalEventOutcome).toBe('processed');
    expect(callOrder).toEqual(['hasProcessed', 'process', 'markProcessed']);
    expect(idempotencyStore.markProcessed).toHaveBeenCalledWith(NOTIFICATION_ID);
  });

  it('scenario 2: a duplicate notification is ignored — processor is never called', async () => {
    const idempotencyStore = new InMemoryIdempotencyStore();
    await idempotencyStore.markProcessed(NOTIFICATION_ID);
    const processor = { process: vi.fn() };
    const journeyStatusService = new JourneyStatusService(idempotencyStore, processor, silentLogger);

    const terminalEventOutcome = await journeyStatusService.handleTerminalEvent(terminalEvent());

    expect(terminalEventOutcome).toBe('duplicate');
    expect(processor.process).not.toHaveBeenCalled();
    expect(silentLogger.info).toHaveBeenCalledWith(
      expect.objectContaining({ notificationId: NOTIFICATION_ID }),
      'Duplicate Fenergo notification ignored',
    );
  });

  it('scenario 3: a failed processing attempt is NOT marked processed', async () => {
    const idempotencyStore = new InMemoryIdempotencyStore();
    const processor = { process: vi.fn().mockRejectedValue(new Error('downstream unavailable')) };
    const journeyStatusService = new JourneyStatusService(idempotencyStore, processor, silentLogger);

    await expect(journeyStatusService.handleTerminalEvent(terminalEvent())).rejects.toBeInstanceOf(
      JourneyStatusProcessingError,
    );
    expect(await idempotencyStore.hasProcessed(NOTIFICATION_ID)).toBe(false);
  });

  it('scenario 4: a retry after a failure processes the notification again and then marks it', async () => {
    const idempotencyStore = new InMemoryIdempotencyStore();
    const processor = {
      process: vi.fn().mockRejectedValueOnce(new Error('transient failure')).mockResolvedValue(undefined),
    };
    const journeyStatusService = new JourneyStatusService(idempotencyStore, processor, silentLogger);

    await expect(journeyStatusService.handleTerminalEvent(terminalEvent())).rejects.toBeInstanceOf(
      JourneyStatusProcessingError,
    );
    const retryOutcome = await journeyStatusService.handleTerminalEvent(terminalEvent());

    expect(retryOutcome).toBe('processed');
    expect(processor.process).toHaveBeenCalledTimes(2);
    expect(await idempotencyStore.hasProcessed(NOTIFICATION_ID)).toBe(true);
  });

  it('scenario 5: after a successful processing, the same notification becomes a duplicate', async () => {
    const idempotencyStore = new InMemoryIdempotencyStore();
    const processor = { process: vi.fn().mockResolvedValue(undefined) };
    const journeyStatusService = new JourneyStatusService(idempotencyStore, processor, silentLogger);

    expect(await journeyStatusService.handleTerminalEvent(terminalEvent())).toBe('processed');
    expect(await journeyStatusService.handleTerminalEvent(terminalEvent())).toBe('duplicate');
    expect(processor.process).toHaveBeenCalledTimes(1);
  });

  it('scenario 6: distinct notification ids are processed independently', async () => {
    const idempotencyStore = new InMemoryIdempotencyStore();
    const processor = { process: vi.fn().mockResolvedValue(undefined) };
    const journeyStatusService = new JourneyStatusService(idempotencyStore, processor, silentLogger);

    expect(await journeyStatusService.handleTerminalEvent(terminalEvent())).toBe('processed');
    expect(
      await journeyStatusService.handleTerminalEvent(
        terminalEvent({ notificationId: '00000000-0000-0000-0000-000000000009' }),
      ),
    ).toBe('processed');
    expect(processor.process).toHaveBeenCalledTimes(2);
  });
});

describe('JourneyStatusService journey query enrichment', () => {
  it('fills missing journeyInstanceId/entityId from the Journey Query response', async () => {
    const journeyClient = stubJourneyClient();
    const processor = { process: vi.fn().mockResolvedValue(undefined) };
    const journeyStatusService = new JourneyStatusService(
      new InMemoryIdempotencyStore(),
      processor,
      silentLogger,
      journeyClient,
    );

    await journeyStatusService.handleTerminalEvent(terminalEvent(), RELATIVE_URL);

    expect(journeyClient.getJourneyDetails).toHaveBeenCalledWith(RELATIVE_URL, undefined);
    expect(processor.process).toHaveBeenCalledWith(
      expect.objectContaining({ journeyInstanceId: JOURNEY_INSTANCE_ID, entityId: ENTITY_ID }),
    );
  });

  it('never overwrites identifiers already present on the event', async () => {
    const journeyClient = stubJourneyClient();
    const processor = { process: vi.fn().mockResolvedValue(undefined) };
    const journeyStatusService = new JourneyStatusService(
      new InMemoryIdempotencyStore(),
      processor,
      silentLogger,
      journeyClient,
    );
    const existingJourneyInstanceId = '00000000-0000-0000-0000-00000000000a';

    await journeyStatusService.handleTerminalEvent(
      terminalEvent({ journeyInstanceId: existingJourneyInstanceId }),
      RELATIVE_URL,
    );

    expect(processor.process).toHaveBeenCalledWith(
      expect.objectContaining({ journeyInstanceId: existingJourneyInstanceId }),
    );
  });

  it('skips the Journey Query when the event already carries both identifiers', async () => {
    const journeyClient = stubJourneyClient();
    const processor = { process: vi.fn().mockResolvedValue(undefined) };
    const journeyStatusService = new JourneyStatusService(
      new InMemoryIdempotencyStore(),
      processor,
      silentLogger,
      journeyClient,
    );

    await journeyStatusService.handleTerminalEvent(
      terminalEvent({ journeyInstanceId: JOURNEY_INSTANCE_ID, entityId: ENTITY_ID }),
      RELATIVE_URL,
    );

    expect(journeyClient.getJourneyDetails).not.toHaveBeenCalled();
  });

  it('skips the Journey Query when no client is configured or no relative URL was delivered', async () => {
    const processor = { process: vi.fn().mockResolvedValue(undefined) };
    const withoutClient = new JourneyStatusService(new InMemoryIdempotencyStore(), processor, silentLogger);
    expect(await withoutClient.handleTerminalEvent(terminalEvent(), RELATIVE_URL)).toBe('processed');

    const journeyClient = stubJourneyClient();
    const withoutRelativeUrl = new JourneyStatusService(
      new InMemoryIdempotencyStore(),
      processor,
      silentLogger,
      journeyClient,
    );
    expect(
      await withoutRelativeUrl.handleTerminalEvent(
        terminalEvent({ notificationId: '00000000-0000-0000-0000-000000000008' }),
      ),
    ).toBe('processed');
    expect(journeyClient.getJourneyDetails).not.toHaveBeenCalled();
  });

  it('propagates a JourneyQueryError and leaves the notification unmarked (retryable)', async () => {
    const failingJourneyClient = {
      getJourneyDetails: vi.fn().mockRejectedValue(new JourneyQueryError('Journey Query returned HTTP 503', 503)),
    } as unknown as FenergoJourneyClient;
    const idempotencyStore = new InMemoryIdempotencyStore();
    const processor = { process: vi.fn() };
    const journeyStatusService = new JourneyStatusService(
      idempotencyStore,
      processor,
      silentLogger,
      failingJourneyClient,
    );

    await expect(journeyStatusService.handleTerminalEvent(terminalEvent(), RELATIVE_URL)).rejects.toBeInstanceOf(
      JourneyQueryError,
    );
    expect(processor.process).not.toHaveBeenCalled();
    expect(await idempotencyStore.hasProcessed(NOTIFICATION_ID)).toBe(false);
  });
});

describe('InMemoryIdempotencyStore', () => {
  it('reports unseen ids as unprocessed and remembers marked ids', async () => {
    const idempotencyStore = new InMemoryIdempotencyStore();
    expect(await idempotencyStore.hasProcessed(NOTIFICATION_ID)).toBe(false);
    await idempotencyStore.markProcessed(NOTIFICATION_ID);
    expect(await idempotencyStore.hasProcessed(NOTIFICATION_ID)).toBe(true);
  });

  it('evicts the oldest entry once the configured capacity is reached', async () => {
    const idempotencyStore = new InMemoryIdempotencyStore(2);
    await idempotencyStore.markProcessed('notification-a');
    await idempotencyStore.markProcessed('notification-b');
    await idempotencyStore.markProcessed('notification-c');
    expect(await idempotencyStore.hasProcessed('notification-a')).toBe(false);
    expect(await idempotencyStore.hasProcessed('notification-b')).toBe(true);
    expect(await idempotencyStore.hasProcessed('notification-c')).toBe(true);
  });

  it('rejects a non-positive capacity', () => {
    expect(() => new InMemoryIdempotencyStore(0)).toThrow();
  });
});
