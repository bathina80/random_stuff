import type { AppConfig } from '../../src/config/config';

export const TEST_WEBHOOK_SECRET = 'test-webhook-secret-not-a-real-secret';

/** Baseline non-local test configuration; override per scenario. */
export function createTestConfig(configOverrides: Partial<AppConfig> = {}): AppConfig {
  return {
    port: 0,
    host: '127.0.0.1',
    logLevel: 'silent',
    nodeEnv: 'test',
    isLocalEnvironment: false,
    fenergoBaseUrl: 'https://fenergo-api.example.invalid',
    fenergoWebhookSecret: TEST_WEBHOOK_SECRET,
    journeyWebhookEnabled: true,
    signatureValidationEnabled: true,
    journeyQueryTimeoutMs: 1000,
    ...configOverrides,
  };
}
