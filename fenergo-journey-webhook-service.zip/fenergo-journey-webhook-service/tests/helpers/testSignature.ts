import crypto from 'node:crypto';

/**
 * Computes a valid x-fenx-signature header value for a given raw body and
 * secret, exactly as Fenergo does: HMAC-SHA256 over the raw bytes with the
 * UTF-8 secret, UPPERCASE hex, prefixed with "sha256=".
 *
 * ALWAYS call this with the EXACT string/Buffer that will be sent as the HTTP
 * body — never with a re-stringified object.
 */
export function createTestSignature(rawBody: string | Buffer, secret: string): string {
  const rawBodyBytes = typeof rawBody === 'string' ? Buffer.from(rawBody, 'utf8') : rawBody;
  const digestHex = crypto
    .createHmac('sha256', Buffer.from(secret, 'utf8'))
    .update(rawBodyBytes)
    .digest('hex')
    .toUpperCase();
  return `sha256=${digestHex}`;
}
