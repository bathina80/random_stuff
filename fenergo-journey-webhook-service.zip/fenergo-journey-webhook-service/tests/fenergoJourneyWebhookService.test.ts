import { describe, expect, it } from 'vitest';
import {
  normalizeSingleNotification,
  normalizeWebhookPayload,
  resolveTerminalStatus,
  toJourneyEndStatusEvent,
} from '../src/services/fenergoJourneyWebhookService';
import { InvalidWebhookPayloadError } from '../src/types/errors';

const NOTIFICATION_ID = '00000000-0000-0000-0000-000000000001';
const TENANT_ID = '00000000-0000-0000-0000-000000000002';
const JOURNEY_INSTANCE_ID = '00000000-0000-0000-0000-000000000003';
const CORRELATION_ID = '00000000-0000-0000-0000-000000000004';
const CAUSATION_ID = '00000000-0000-0000-0000-000000000005';

function pascalCaseNotification(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    Id: NOTIFICATION_ID,
    TenantId: TENANT_ID,
    EventType: 'journey:instancecompleted',
    RelativeUrl: `/journeyquery/api/journeys/${JOURNEY_INSTANCE_ID}`,
    Payload: { journeyInstanceId: JOURNEY_INSTANCE_ID },
    When: '2026-01-01T00:00:00Z',
    CorrelationId: CORRELATION_ID,
    CausationId: CAUSATION_ID,
    ...overrides,
  };
}

function camelCaseNotification(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    id: NOTIFICATION_ID,
    tenantId: TENANT_ID,
    eventType: 'journey:instancecancelled',
    url: `/journeyquery/api/journeys/${JOURNEY_INSTANCE_ID}`,
    payload: { journeyInstanceId: JOURNEY_INSTANCE_ID },
    when: '2026-01-01T00:00:00Z',
    correlationId: CORRELATION_ID,
    causationId: CAUSATION_ID,
    ...overrides,
  };
}

describe('normalizeWebhookPayload', () => {
  it('normalizes a PascalCase single notification', () => {
    const normalizedRequest = normalizeWebhookPayload(pascalCaseNotification());
    expect(normalizedRequest.notifications).toHaveLength(1);
    const normalizedNotification = normalizedRequest.notifications[0];
    expect(normalizedNotification).toMatchObject({
      notificationId: NOTIFICATION_ID,
      tenantId: TENANT_ID,
      eventType: 'journey:instancecompleted',
      relativeUrl: `/journeyquery/api/journeys/${JOURNEY_INSTANCE_ID}`,
      occurredAt: '2026-01-01T00:00:00Z',
      correlationId: CORRELATION_ID,
      causationId: CAUSATION_ID,
    });
    expect(normalizedNotification.payload).toEqual({ journeyInstanceId: JOURNEY_INSTANCE_ID });
  });

  it('normalizes a camelCase single notification into the SAME internal model', () => {
    const normalizedRequest = normalizeWebhookPayload(camelCaseNotification());
    expect(normalizedRequest.notifications[0]).toMatchObject({
      notificationId: NOTIFICATION_ID,
      tenantId: TENANT_ID,
      eventType: 'journey:instancecancelled',
      relativeUrl: `/journeyquery/api/journeys/${JOURNEY_INSTANCE_ID}`,
      correlationId: CORRELATION_ID,
      causationId: CAUSATION_ID,
    });
  });

  it('normalizes a batch envelope with mixed-casing notifications and carries the batchId onto each', () => {
    const batchBody = {
      batchId: '00000000-0000-0000-0000-00000000000b',
      notifications: [pascalCaseNotification(), camelCaseNotification({ id: `${NOTIFICATION_ID}-second` })],
      moreAvailable: true,
    };
    const normalizedRequest = normalizeWebhookPayload(batchBody);
    expect(normalizedRequest.batchId).toBe('00000000-0000-0000-0000-00000000000b');
    expect(normalizedRequest.moreAvailable).toBe(true);
    expect(normalizedRequest.notifications).toHaveLength(2);
    expect(normalizedRequest.notifications.every((notification) => notification.batchId === batchBody.batchId)).toBe(
      true,
    );
  });

  it('accepts an empty notifications array', () => {
    const normalizedRequest = normalizeWebhookPayload({ batchId: 'batch-empty', notifications: [] });
    expect(normalizedRequest.notifications).toHaveLength(0);
  });

  it('treats Payload: null (PascalCase) and payload: null (camelCase) as a null payload', () => {
    expect(normalizeWebhookPayload(pascalCaseNotification({ Payload: null })).notifications[0].payload).toBeNull();
    expect(normalizeWebhookPayload(camelCaseNotification({ payload: null })).notifications[0].payload).toBeNull();
  });

  it('tolerates missing optional fields', () => {
    const minimalNotification = { Id: NOTIFICATION_ID, EventType: 'journey:instancecompleted' };
    const normalizedNotification = normalizeWebhookPayload(minimalNotification).notifications[0];
    expect(normalizedNotification.notificationId).toBe(NOTIFICATION_ID);
    expect(normalizedNotification.tenantId).toBeUndefined();
    expect(normalizedNotification.relativeUrl).toBeUndefined();
    expect(normalizedNotification.payload).toBeNull();
    expect(normalizedNotification.occurredAt).toBeUndefined();
    expect(normalizedNotification.correlationId).toBeUndefined();
    expect(normalizedNotification.causationId).toBeUndefined();
  });

  it('rejects malformed payloads with InvalidWebhookPayloadError', () => {
    expect(() => normalizeWebhookPayload(null)).toThrow(InvalidWebhookPayloadError);
    expect(() => normalizeWebhookPayload('not-an-object')).toThrow(InvalidWebhookPayloadError);
    expect(() => normalizeWebhookPayload([])).toThrow(InvalidWebhookPayloadError);
    expect(() => normalizeWebhookPayload({ notifications: 'not-an-array' })).toThrow(InvalidWebhookPayloadError);
    expect(() => normalizeWebhookPayload({ EventType: 'journey:instancecompleted' })).toThrow(
      InvalidWebhookPayloadError,
    );
    expect(() => normalizeWebhookPayload({ Id: NOTIFICATION_ID })).toThrow(InvalidWebhookPayloadError);
    expect(() => normalizeWebhookPayload({ notifications: [{ Id: NOTIFICATION_ID }] })).toThrow(
      InvalidWebhookPayloadError,
    );
  });

  it('rejects a notification that is not an object inside a batch', () => {
    expect(() => normalizeSingleNotification(42)).toThrow(InvalidWebhookPayloadError);
    expect(() => normalizeWebhookPayload({ notifications: [null] })).toThrow(InvalidWebhookPayloadError);
  });
});

describe('resolveTerminalStatus', () => {
  it('maps the two supported event types (case-insensitively) to terminal statuses', () => {
    expect(resolveTerminalStatus('journey:instancecompleted')).toBe('COMPLETED');
    expect(resolveTerminalStatus('Journey:InstanceCompleted')).toBe('COMPLETED');
    expect(resolveTerminalStatus('journey:instancecancelled')).toBe('CANCELLED');
    expect(resolveTerminalStatus('JOURNEY:INSTANCECANCELLED')).toBe('CANCELLED');
  });

  it('returns undefined for every other event type', () => {
    for (const unsupportedEventType of [
      'journey:taskcompleted',
      'journey:integrationflowcompleted',
      'journey:integrationflowfailed',
      'journey:slabreached',
      'journey:instancepaused',
      'journey:instanceinprogress',
      'entitydata:created',
      '',
    ]) {
      expect(resolveTerminalStatus(unsupportedEventType)).toBeUndefined();
    }
  });
});

describe('toJourneyEndStatusEvent', () => {
  it('extracts journeyInstanceId and entityId defensively from the payload', () => {
    const normalizedNotification = normalizeWebhookPayload(
      pascalCaseNotification({
        Payload: { JourneyInstanceId: JOURNEY_INSTANCE_ID, EntityId: CAUSATION_ID },
      }),
    ).notifications[0];
    const journeyEndStatusEvent = toJourneyEndStatusEvent(normalizedNotification, 'COMPLETED');
    expect(journeyEndStatusEvent).toMatchObject({
      notificationId: NOTIFICATION_ID,
      journeyInstanceId: JOURNEY_INSTANCE_ID,
      entityId: CAUSATION_ID,
      status: 'COMPLETED',
      eventType: 'journey:instancecompleted',
      tenantId: TENANT_ID,
      correlationId: CORRELATION_ID,
      causationId: CAUSATION_ID,
    });
  });

  it('leaves identifiers undefined when the payload is null or lacks them', () => {
    const normalizedNotification = normalizeWebhookPayload(pascalCaseNotification({ Payload: null }))
      .notifications[0];
    const journeyEndStatusEvent = toJourneyEndStatusEvent(normalizedNotification, 'CANCELLED');
    expect(journeyEndStatusEvent.journeyInstanceId).toBeUndefined();
    expect(journeyEndStatusEvent.entityId).toBeUndefined();
    expect(journeyEndStatusEvent.status).toBe('CANCELLED');
  });
});
