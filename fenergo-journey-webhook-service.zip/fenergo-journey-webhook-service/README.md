# fenergo-journey-webhook-service

A generic, production-quality webhook service that receives **Fenergo Event Notification** deliveries, reacts to **journey terminal statuses** (completed / cancelled), and hands a clean internal domain event to a replaceable downstream processor.

This repository is fully **de-identified**: it contains no company names, internal URLs, real tenant or journey identifiers, credentials, or proprietary business rules. Every example value is a placeholder (`<FENERGO_BASE_URL>`, `<WEBHOOK_SECRET>`, all-zeros UUIDs).

## 1. Overview

Fenergo delivers event notifications over HTTPS with an HMAC-SHA256 signature in the `x-fenx-signature` header. This service:

- validates the signature over the **exact raw request body**,
- normalizes single-notification (PascalCase **and** camelCase) and batch deliveries into one internal model,
- reacts only to `journey:instancecompleted` (→ `COMPLETED`) and `journey:instancecancelled` (→ `CANCELLED`),
- safely acknowledges and ignores every other event type,
- guards against duplicate deliveries with a notification-Id idempotency store,
- optionally enriches the event via the Fenergo Journey Query API,
- delegates to a `JourneyEndStatusProcessor` interface that can be swapped for Kafka, a database, a CRM update, SMTP, or another REST call without touching the webhook plumbing.

## 2. Supported events

| Event type (case-insensitive)  | Action                              |
| ------------------------------ | ----------------------------------- |
| `journey:instancecompleted`    | Emit `JourneyEndStatusEvent` with status `COMPLETED` |
| `journey:instancecancelled`    | Emit `JourneyEndStatusEvent` with status `CANCELLED` |
| Anything else (task completion, integration flow completed/failed, SLA, paused, in-progress, …) | Logged as `Unsupported Fenergo event ignored`, acknowledged with **202** |

## 3. Architecture and request flow

```
POST /api/webhooks/fenergo/journey-status
  │
  ├─ route-scoped content-type parser
  │     stores exact bytes as request.rawBody (Buffer) + JSON.parses request.body
  │
  ├─ FenergoJourneyWebhookController
  │     HMAC check (FenergoSignatureService) ──── invalid ──► 401
  │
  ├─ FenergoJourneyWebhookService
  │     normalizeWebhookPayload: single (PascalCase | camelCase) | batch ──► one model
  │     malformed ──► 400
  │     unsupported event ──► ignored (202)
  │
  ├─ JourneyStatusService  (per terminal notification)
  │     1. IdempotencyStore.hasProcessed?  ── yes ──► duplicate (202)
  │     2. FenergoJourneyClient (optional enrichment via <FENERGO_BASE_URL>/<RelativeUrl>)
  │     3. JourneyEndStatusProcessor.process(event)
  │     4. IdempotencyStore.markProcessed  (ONLY after success)
  │
  └─ 202 summary  |  500 on processing/downstream failure (Fenergo retry desirable)
```

## 4. Repository structure

```
src/
  app.ts                                    Fastify wiring + DI seams + sanitized error handler
  server.ts                                 Startup, config loading, graceful shutdown
  config/config.ts                          Env validation, fail-fast, local-only bypass rules
  controllers/fenergoJourneyWebhookController.ts   Thin HTTP controller (status-code mapping)
  routes/fenergoJourneyWebhookRoutes.ts     Route + route-scoped raw-body parser
  services/fenergoJourneyWebhookService.ts  Payload normalization + event routing
  services/fenergoSignatureService.ts       Reusable HMAC validation (x-fenx-signature)
  services/fenergoJourneyClient.ts          Journey Query HTTP client
  services/journeyStatusService.ts          Idempotency → enrichment → processing orchestration
  services/loggingJourneyEndStatusProcessor.ts  Default (logging-only) downstream processor
  types/                                    Wire types, domain types, errors, logger contract
  utils/idempotencyStore.ts                 IdempotencyStore interface + in-memory impl
tests/                                      Vitest suites (signature, normalization, status, controller)
postman/                                    Postman collection + sample bodies (all-zeros UUIDs)
scripts/generate-signature.js               CLI helper to compute x-fenx-signature
Dockerfile                                  Multi-stage, non-root production image
```

## 5. Requirements

- Node.js **22+** (native `fetch` and `AbortSignal.timeout` are used)
- npm

## 6. Installation

```bash
npm install
```

## 7. Configuration

Copy `.env.example` to `.env` and fill in your environment's values. All variables:

| Variable | Default | Description |
| --- | --- | --- |
| `PORT` | `3000` | HTTP listen port |
| `HOST` | `0.0.0.0` | HTTP listen host |
| `LOG_LEVEL` | `info` | Pino log level |
| `NODE_ENV` | `local` | Environment name; the signature bypass works **only** with `local` |
| `FENERGO_BASE_URL` | — | Base URL for Journey Query calls (`<FENERGO_BASE_URL>`); required outside local |
| `FENERGO_WEBHOOK_SECRET` | — | HMAC secret registered with the webhook subscription (`<WEBHOOK_SECRET>`); required whenever validation is enabled, and always outside local |
| `FENERGO_JOURNEY_WEBHOOK_ENABLED` | `true` | Feature flag; when `false` the endpoint acknowledges (202) without processing |
| `FENERGO_SIGNATURE_VALIDATION_ENABLED` | `true` | Only honored when `NODE_ENV=local`; **every non-local environment always validates** |
| `FENERGO_JOURNEY_QUERY_TIMEOUT_MS` | `5000` | Journey Query HTTP timeout |

Startup **fails fast** with a clear error naming any missing required variable. Error messages never echo secret values.

## 8. Running locally

```bash
cp .env.example .env          # then set FENERGO_WEBHOOK_SECRET to any local test value
npm run dev                   # tsx watch mode
# or
npm run build && npm start
```

## 9. Running tests

```bash
npm test                      # full Vitest suite
npm run test:coverage         # with V8 coverage (80% thresholds enforced)
npm run lint                  # eslint (typescript-eslint recommended rules)
```

## 10. API contract

`POST /api/webhooks/fenergo/journey-status` (content-type `application/json`)

| Status | Meaning |
| --- | --- |
| `202` | Notification(s) accepted: processed, duplicate, unsupported-and-ignored, or feature flag off |
| `401` | Missing or invalid HMAC signature |
| `400` | Malformed payload (invalid JSON, empty body, or missing mandatory `Id`/`EventType`) |
| `500` | Unexpected processing or downstream failure — Fenergo retry is desirable |

The 202 body summarizes the outcome: `{ status, received, processed, duplicates, ignored, batchId?, moreAvailable? }`. Error responses are sanitized — **no stack traces are ever exposed**.

`GET /health` returns `{ "status": "ok" }` for liveness probes.

## 11. Payload formats

All three wire shapes are normalized into one internal model — there is **no duplicated business logic** between them.

Single notification, PascalCase:

```json
{
  "Id": "00000000-0000-0000-0000-000000000001",
  "TenantId": "00000000-0000-0000-0000-000000000002",
  "EventType": "journey:instancecompleted",
  "RelativeUrl": "/journeyquery/api/journeys/00000000-0000-0000-0000-000000000003",
  "Payload": { "journeyInstanceId": "00000000-0000-0000-0000-000000000003" },
  "When": "2026-01-01T00:00:00Z",
  "CorrelationId": "00000000-0000-0000-0000-000000000004",
  "CausationId": "00000000-0000-0000-0000-000000000005"
}
```

Single notification, camelCase: same fields as `id`, `tenantId`, `eventType`, `url`, `payload`, `when`, `correlationId`, `causationId`.

Batch envelope:

```json
{
  "batchId": "00000000-0000-0000-0000-000000000004",
  "notifications": [ { "...": "single notifications, either casing" } ],
  "moreAvailable": false
}
```

`moreAvailable` is treated as **metadata only** — this service never polls Fenergo for further notifications. `Payload`/`payload` may be `null`.

## 12. HMAC signature validation — read this first

> ⚠️ **The HMAC is computed over the EXACT raw HTTP body bytes as received on the wire.**
> Parsing and re-stringifying the body (`JSON.stringify(request.body)`), pretty-printing,
> trimming, changing whitespace or line endings, or reordering properties **all change the
> bytes and therefore change the signature**. This is the single most common cause of
> "signature mismatch" incidents.

Implementation (`FenergoSignatureService`):

- Digest: `crypto.createHmac("sha256", Buffer.from(secret, "utf8")).update(rawBodyBytes).digest("hex")` — the secret's UTF-8 bytes are the HMAC key directly (the secret is **not** hashed first).
- Header: `x-fenx-signature: sha256=<HEX>`. Fenergo sends UPPERCASE hex with the `sha256=` prefix; the service accepts the digest with or without the prefix and in any hex case.
- The received value is pre-validated against `/^[0-9a-f]{64}$/` (after normalization) before comparison, because `Buffer.from(hex)` silently truncates invalid input.
- Comparison uses `crypto.timingSafeEqual` (constant-time).
- The raw bytes are captured by a **route-scoped** `application/json` content-type parser (`parseAs: "buffer"`) that stores them untouched on `request.rawBody` and separately `JSON.parse`s a decoded copy for `request.body`. Fastify's default JSON parsing is untouched for any other route.
- The secret, the `Authorization` header, and complete request headers are never logged; the logger additionally redacts `authorization` and `x-fenx-signature` defensively.
- Note that a `Bearer` token in an `Authorization` header is **not** the webhook secret and is never used for signature validation.

## 13. Local development signature bypass

Signature validation can be disabled **only** when **both** hold:

- `NODE_ENV=local`
- `FENERGO_SIGNATURE_VALIDATION_ENABLED=false`

The service then logs `Fenergo HMAC validation disabled for local development` at WARN on startup. In every non-local environment the flag is ignored and validation always runs. Secret values are never logged in any mode.

## 14. Idempotency

Fenergo's HMAC scheme has no timestamp, so there is no replay protection at the signature level, and webhook delivery is at-least-once. The notification `Id` is therefore used as an idempotency key:

1. `IdempotencyStore.hasProcessed(id)` — duplicate → log `Duplicate Fenergo notification ignored` + 202.
2. Process the event (enrichment + downstream processor).
3. `IdempotencyStore.markProcessed(id)` — **only on success**. A failed notification stays unmarked, so a Fenergo retry processes it again.

The bundled `InMemoryIdempotencyStore` is **local / single-instance only** (lost on restart, not shared across replicas, oldest-first eviction at capacity). Production deployments should use Redis (`SETNX` + TTL) or a database unique constraint.

## 15. Journey Query client

`FenergoJourneyClient` calls `GET <FENERGO_BASE_URL>/<RelativeUrl>` (native `fetch`, `AbortSignal.timeout`) and returns a deliberately minimal, defensive `FenergoJourneyDetails` — best-effort `journeyInstanceId` / `entityId` / `journeyStatus` plus the full `raw` body. It is used only to fill identifiers the notification payload did not carry. Failures raise `JourneyQueryError` → HTTP 500, so Fenergo retries and nothing is marked processed. Authentication against the real Fenergo API (e.g. OAuth2 client credentials) is intentionally out of scope for this generic repository and must be added per environment.

## 16. Downstream processing (extension point)

```ts
interface JourneyEndStatusProcessor {
  process(event: JourneyEndStatusEvent): Promise<void>;
}
```

The default `LoggingJourneyEndStatusProcessor` only logs. Inject your own implementation through `buildApp(config, { journeyEndStatusProcessor })` — Kafka producer, database write, CRM/case-management update, SMTP notification, or another REST call — without changing the controller, routes, or webhook service.

## 17. Logging

Structured Pino logging with a **whitelist of safe fields only**: `notificationId`, `batchId`, `eventType`, `journeyInstanceId`, `tenantId`, `correlationId`, `causationId`, `terminalStatus`, `processingDurationMs` (plus `rawBodyLength`/`statusCode` diagnostics). Key messages: `Fenergo journey webhook received`, `Fenergo signature validation succeeded|failed`, `Unsupported Fenergo event ignored`, `Duplicate Fenergo notification ignored`, `Journey terminal event received`, `Journey Query request started|response received|request failed`, `Journey end status processing started|processed successfully`, `Fenergo webhook processing failed`.

Never logged: the webhook secret, bearer tokens, `Authorization` headers, client secrets, complete HTTP header sets, or full sensitive payloads.

## 18. Error model

`InvalidWebhookSignatureError`, `InvalidWebhookPayloadError` (→ 400), `JourneyQueryError` (→ 500), `JourneyStatusProcessingError` (→ 500) — see `src/types/errors.ts`.

## 19. Testing with Postman and curl

Import `postman/fenergo-journey-webhook.postman_collection.json`, set the collection variables `baseUrl` and `webhookSecret`, and send — the collection-level pre-request script computes `x-fenx-signature` over the exact raw body with CryptoJS.

With curl (always `--data-binary` so the signed bytes are the sent bytes):

```bash
SIGNATURE=$(node scripts/generate-signature.js postman/sample-single-completed.json "<WEBHOOK_SECRET>")
curl -i -X POST http://localhost:3000/api/webhooks/fenergo/journey-status \
  -H "content-type: application/json" \
  -H "x-fenx-signature: $SIGNATURE" \
  --data-binary @postman/sample-single-completed.json
```

## 20. Docker

```bash
docker build -t fenergo-journey-webhook-service .
docker run --rm -p 3000:3000 \
  -e NODE_ENV=production \
  -e FENERGO_BASE_URL="<FENERGO_BASE_URL>" \
  -e FENERGO_WEBHOOK_SECRET="<WEBHOOK_SECRET>" \
  fenergo-journey-webhook-service
```

Multi-stage build, maintained `node:22-alpine` base, runs as the non-root `node` user, no `chmod 777`, no secrets in the image.

## 21. Production considerations

- Replace `InMemoryIdempotencyStore` with a shared store (Redis/database) before running more than one replica.
- Add authentication to `FenergoJourneyClient` for your environment.
- Terminate TLS in front of the service; the webhook must only be reachable over HTTPS.
- Rotate the webhook secret via your secret manager. Fenergo stores only a hash of the registered secret — a lost secret cannot be recovered, only re-registered.
- Consider a dead-letter path in your `JourneyEndStatusProcessor` if downstream outages can outlast Fenergo's retry window.
- Wire `/health` into liveness/readiness probes.

## 22. Confirm against a real Fenergo lower environment

Before production use, verify with real (lower-environment) traffic:

- the exact event-type strings and casing for journey completion/cancellation,
- whether `RelativeUrl` vs `url` is populated for your tenant's notification version,
- the Journey Query response schema (this repo probes only common field-name casings and keeps the full body in `raw`),
- which identifiers (`journeyInstanceId`, `entityId`) actually appear in the notification `Payload`,
- batch envelope behavior (`batchId`, `moreAvailable`) for your subscription configuration,
- signature header format from your Fenergo version (prefix present or not — both are accepted).

## 23. De-identification statement

This repository is generic by construction: placeholders (`<FENERGO_BASE_URL>`, `<WEBHOOK_SECRET>`, `<COMPANY>`-free naming) and synthetic all-zeros UUIDs are used everywhere; no real organization, tenant, journey, entity, employee, customer, credential, or internal URL appears in code, tests, fixtures, configuration, or documentation.
