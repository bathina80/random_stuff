'use strict';

// Mock DATA SOURCE for a Fenergo External Data Flow Provider.
// This is NOT a full hosted Fenergo External Data Adapter implementation.
// Flow Studio is responsible for wrapping the responses according to its End-task contract.
const http = require('node:http');
const { URL } = require('node:url');
const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.MOCK_API_KEY || '';

const companies = [
  {
    id: 'MOCK-001', name: 'Cedarstone Technologies LLC',
    country: 'USA', registrationNumber: 'TX-100100',
    address: '100 Example Road, Austin, TX', website: 'https://example.com'
  },
  {
    id: 'MOCK-002', name: 'Cedarstone Holdings Inc',
    country: 'USA', registrationNumber: 'TX-100200',
    address: '200 Sample Avenue, Dallas, TX', website: 'https://example.org'
  }
];

const textField = (Name, FriendlyName) => ({ Name, FriendlyName, Type: 'text' });
const fields = {
  ExternalDataIdentifier: textField('ExternalDataIdentifier', 'External Data Identifier'),
  LegalEntityName: textField('LegalEntityName', 'Legal Entity Name'),
  CountryOfIncorporation: textField('CountryOfIncorporation', 'Country of Incorporation'),
  Address: textField('Address', 'Address'),
  RegistrationNumber: textField('RegistrationNumber', 'Registration Number'),
  Website: textField('Website', 'Website')
};
const schema = {
  Lookups: [],
  Schema: {
    SearchRequest: { SearchCriteria: { Fields: [fields.LegalEntityName] } },
    SearchResponse: { SearchResultsData: { Fields: [
      fields.ExternalDataIdentifier, fields.LegalEntityName,
      fields.CountryOfIncorporation, fields.Address
    ] } },
    GetRequest: { RequestData: { Fields: [fields.ExternalDataIdentifier] } },
    GetResponse: {
      ClientData: { Fields: [
        fields.ExternalDataIdentifier, fields.LegalEntityName,
        fields.CountryOfIncorporation, fields.RegistrationNumber, fields.Website
      ] },
      AssociatedEntitiesCompanyData: { Fields: [] },
      AssociatedEntitiesIndividualData: { Fields: [] },
      AssociationsData: { Fields: [] }
    }
  }
};

const send = (res, status, obj) => {
  const json = JSON.stringify(obj);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'content-length': Buffer.byteLength(json)
  });
  res.end(json);
};

const mapSearch = c => ({
  Id: c.id,
  entityType: 'Company',
  fullName: c.name,
  matchHint: 'Partial',
  matchScore: 85,
  data: {
    ExternalDataIdentifier: c.id,
    LegalEntityName: c.name,
    CountryOfIncorporation: c.country,
    Address: c.address
  }
});

const server = http.createServer(async (req, res) => {
  const path = new URL(req.url, 'http://localhost').pathname;
  if (path === '/health' && req.method === 'GET') return send(res, 200, { status: 'ok' });
  // Always require a secret when bound beyond localhost.
  if (!API_KEY && HOST !== '127.0.0.1' && HOST !== 'localhost') {
    return send(res, 503, { error: 'Set MOCK_API_KEY before exposing service' });
  }
  if (API_KEY && req.headers.authorization !== `Bearer ${API_KEY}`) {
    return send(res, 401, { error: 'Unauthorized' });
  }
  if (req.method !== 'POST' || !['/test', '/search', '/get'].includes(path)) {
    return send(res, 404, { error: 'Unknown route' });
  }
  let body = '';
  try {
    for await (const chunk of req) {
      body += chunk;
      if (Buffer.byteLength(body) > 100_000) {
        return send(res, 413, { error: 'Request too large' });
      }
    }
    const payload = body ? JSON.parse(body) : {};
    const input = payload.Request ?? payload.request ?? payload;
    if (path === '/test') return send(res, 200, { adapterSchema: schema });
    if (path === '/search') {
      const criteria = input.SearchCriteria ?? input.searchCriteria ?? input;
      const term = String(criteria.LegalEntityName ?? criteria.legalEntityName ?? '').trim().toLowerCase();
      const matches = term ? companies.filter(c => c.name.toLowerCase().includes(term)) : [];
      return send(res, 200, { results: matches.map(c => ({
        ...mapSearch(c),
        matchHint: c.name.toLowerCase() === term ? 'Exact' : 'Partial',
        matchScore: c.name.toLowerCase() === term ? 99 : 85
      })) });
    }
    const id = String(input.Id ?? input.id ?? input.ExternalDataIdentifier ?? '');
    const company = companies.find(c => c.id === id);
    if (!company) return send(res, 404, { error: 'Company not found', id });
    return send(res, 200, {
      documents: null,
      client: {
        Id: company.id, entityType: 'Company', fullName: company.name,
        data: {
          ExternalDataIdentifier: company.id,
          LegalEntityName: company.name,
          CountryOfIncorporation: company.country,
          RegistrationNumber: company.registrationNumber,
          Website: company.website
        }
      },
      hierarchy: { associatedEntities: [], associations: [] }
    });
  } catch (err) {
    return send(res, 400, { error: 'Invalid JSON request' });
  }
});
server.listen(PORT, HOST, () => console.log(`Mock data source listening on http://${HOST}:${PORT}`));
