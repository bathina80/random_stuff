# Fenergo External Data — Mock Data Source POC

This is a mock HTTP data source for **Fenergo Integration Flows / Flow Provider**.
It is **not** a full hosted Fenergo Custom External Data Adapter. It does not implement
Fenergo's encrypted request, HMAC, HTTP 202, or Receptor callback protocol.

## Start

Node.js 18+; no npm installation required.

```bash
node server.js
```

Defaults to `127.0.0.1:3000` for safe local development.

## Test

```bash
curl -sS http://127.0.0.1:3000/health
curl -sS -X POST http://127.0.0.1:3000/test -H 'Content-Type: application/json' -d '{}'
curl -sS -X POST http://127.0.0.1:3000/search -H 'Content-Type: application/json' -d '{"Request":{"EntityType":"Company","SearchCriteria":{"LegalEntityName":"Cedarstone"}}}'
curl -sS -X POST http://127.0.0.1:3000/get -H 'Content-Type: application/json' -d '{"Request":{"EntityType":"Company","Id":"MOCK-001"}}'
```

## Connect to Fenergo Flow Studio

- Host the service on an approved HTTPS endpoint reachable by your Fenergo tenant.
- Require auth for a deployed instance: `MOCK_API_KEY=... HOST=0.0.0.0 PORT=3000 node server.js` behind a secured HTTPS reverse proxy, with firewall / IP restrictions as applicable.
- Configure three External Data Adapter initiated flows (TEST, SEARCH, GET) or use the Gleif Search & Import template as a reference.
- Use an HTTP Invoker POST to `/test`, `/search`, or `/get` with the runtime request as JSON.
- Service outputs are *inner* Fenergo response shapes. Set the Flow End task output according to the **actual Gleif template / tenant Flow Provider contract**; do not assume the whole HTTP response can be pasted into End unchanged.
- Configure provider under Integration Hub > External Data, map three flows, run Test, then map Search Request, Search Response, GET Request, GET Response to Policy.
- Test through Journey Builder `External Data Combined` task. Disable auto-import for initial POC.

## Synthetic demo records

- MOCK-001: Cedarstone Technologies LLC
- MOCK-002: Cedarstone Holdings Inc

Search `Cedarstone` yields both. Search another term yields no results. GET needs the ID exactly as provided by SEARCH.

## Security note

Use only synthetic data. Never expose the local service publicly without HTTPS, authentication, firewall restrictions, and approval under your organization's security process.
